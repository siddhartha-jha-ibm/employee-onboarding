"""
generatesql.py  (v8-enhanced)
==============================
Produces sql_discovery.json + sql_discovery.xlsx from a PowerBuilder project
directory.

Incorporates all fixes from datawindow_metrics_v8.py:
  - Expanded _SKIP_TABLES list (including 'from' for PB source typos)
  - valid_proc_name() filter (dbo/lcur/cursor etc.)
  - is_real_sql() — rejects error messages, constant declarations, giant strings
  - PBSELECT TABLE(NAME=~"tablename") extraction
  - ~" PB escape handling in retrieve= SQL
  - Raised SQL length limit to 3000 chars
  - DECLARE + EXEC deduplication
  - Filter/Sort/Arg extraction (from datawindow_metrics_v8 patterns)
  - Excel output: Queries sheet, Procedures sheet, Tables sheet, Master Summary
  - JOIN condition extraction per query (join_table, join_type, condition)
  - Field-to-table mapping per query (field, source_table)
  - primary_table identification per query
  - table_service_map: {table → owning microservice name} at top level

Output files:
  sql_discovery.json   — structured JSON consumed by agents
  sql_discovery.xlsx   — Excel workbook for human review
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, Any, List, Set
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ─────────────────────────────────────────────────────────────────────────────
# FILE READER
# ─────────────────────────────────────────────────────────────────────────────

def read_file(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    if raw[:2] == b"\xff\xfe":
        text = raw.decode("utf-16-le", errors="replace")
    elif raw[:2] == b"\xfe\xff":
        text = raw.decode("utf-16-be", errors="replace")
    elif raw[:3] == b"\xef\xbb\xbf":
        text = raw[3:].decode("utf-8", errors="replace")
    else:
        try:
            text = raw.decode("utf-8", errors="strict")
            if "\x00" in text:
                text = raw.decode("utf-16", errors="replace")
        except UnicodeDecodeError:
            text = raw.decode("cp1252", errors="replace")
    return text.replace("\r\n", "\n").replace("\r", "\n")


# ─────────────────────────────────────────────────────────────────────────────
# VALIDATION HELPERS
# ─────────────────────────────────────────────────────────────────────────────

_SKIP_TABLES = {
    "select", "where", "and", "or", "not", "null", "as", "set", "into", "values", "case",
    "when", "then", "else", "end", "on", "in", "like", "between", "is", "by", "order",
    "group", "having", "union", "all", "exists", "distinct", "the", "a", "an",
    "lcur", "dbo", "with", "cursor", "sqlca", "sqlda", "true", "false", "from"
}
_SKIP_PROCS = {
    "lcur", "dbo", "with", "a", "b", "c", "null", "cursor",
    "sqlca", "sqlda", "immediate"
}


def valid_table(t: str) -> bool:
    return (t.lower() not in _SKIP_TABLES
            and not re.match(r'^\d+$', t)
            and len(t) > 1)


def valid_proc(name: str) -> bool:
    return (name.lower() not in _SKIP_PROCS
            and len(name) > 2
            and not re.match(r'^\d+$', name))


def is_real_sql(sql: str) -> bool:
    """
    Filters out error-message strings and PB constant declarations mistaken for SQL.
    Returns True only for genuine SQL statements.
    """
    s = sql.strip()
    su = s.upper()

    # Must have FROM/INTO/SET with a valid identifier
    if not re.search(r'\b(FROM\s+[a-zA-Z_]\w*|INTO\s+[a-zA-Z_]\w*|SET\s+\w+\s*=)\b', su):
        return False

    # Reject PB constant declarations
    if re.search(r'\bconstant\s+long\b', s, re.IGNORECASE):
        return False

    # Reject PB code blocks (real SQL never uses // comments)
    if '//' in s:
        return False

    # Reject over-long strings (PB code blocks); real SQL max ~3000 chars
    if len(s) > 3000:
        return False

    # Reject English-sentence SELECT (error message pattern)
    _SENTENCE_WORDS = {
        'a', 'an', 'the', 'another', 'specific', 'new', 'some', 'all', 'any',
        'this', 'that', 'these', 'those', 'each', 'every', 'both', 'few', 'more',
        'most', 'other', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so',
        'than', 'too', 'very', 'just', 'but', 'because', 'as', 'until', 'while'
    }
    m = re.match(r'\bSELECT\s+(\w+)', s, re.IGNORECASE)
    if m and m.group(1).lower() in _SENTENCE_WORDS:
        return False

    # FROM followed by common English word = error message
    m2 = re.search(r'\bFROM\s+([a-zA-Z_]\w*)', su)
    if m2 and m2.group(1).lower() in {
        'the', 'a', 'an', 'this', 'that', 'new', 'all', 'any', 'each', 'some', 'your'
    }:
        return False

    return True


def clean_sql(sql: str) -> str:
    sql = sql.replace('~"', '"').replace("~r~n", " ").replace("~n", " ").replace("~t", " ")
    return re.sub(r"\s+", " ", sql).strip()


# ─────────────────────────────────────────────────────────────────────────────
# TABLE EXTRACTION
# ─────────────────────────────────────────────────────────────────────────────

def extract_tables_from_pbselect(sql: str) -> List[str]:
    tables: set = set()
    for m in re.finditer(r'TABLE\s*\(\s*NAME\s*=\s*~?"?(\w+)', sql, re.IGNORECASE):
        t = m.group(1).lower()
        if valid_table(t):
            tables.add(t)
    return sorted(tables)


def extract_tables_from_sql(sql: str) -> List[str]:
    tables: set = set()
    for m in re.finditer(r"\b(?:FROM|JOIN)\s+(\w+)", sql, re.IGNORECASE):
        if valid_table(m.group(1)):
            tables.add(m.group(1).lower())
    for m in re.finditer(r"\bUPDATE\s+(\w+)\s+SET\b", sql, re.IGNORECASE):
        if valid_table(m.group(1)):
            tables.add(m.group(1).lower())
    for m in re.finditer(r"\bINSERT\s+INTO\s+(\w+)\b", sql, re.IGNORECASE):
        if valid_table(m.group(1)):
            tables.add(m.group(1).lower())
    return sorted(tables)


# ─────────────────────────────────────────────────────────────────────────────
# COLUMN / PARAM HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def extract_cols(sql: str, qtype: str) -> List[str]:
    if qtype != "SELECT":
        return []
    m = re.search(r"\bSELECT\s+(.*?)\s+FROM\b", sql, re.IGNORECASE | re.DOTALL)
    if not m:
        return []
    col_str = m.group(1)
    into_pos = col_str.upper().find(" INTO ")
    if into_pos != -1:
        col_str = col_str[:into_pos]
    col_str = re.sub(r"\w+\s*\([^)]*\)", "", col_str)
    cols = []
    for raw in col_str.split(","):
        c = raw.strip()
        if not c or c == "*":
            continue
        alias = re.search(r"\bAS\s+(\w+)$", c, re.IGNORECASE)
        c = alias.group(1) if alias else c.split(".")[-1].strip()
        if c and len(c) > 1:
            cols.append(c.lower())
    return cols


def extract_params(sql: str) -> List[str]:
    return list(dict.fromkeys(re.findall(r":([a-zA-Z0-9_]+)", sql)))


def extract_join_conditions(sql: str) -> List[Dict]:
    """
    Extract JOIN conditions from SQL: table, join_type, on_condition.
    Captures:
      - Explicit: INNER/LEFT/RIGHT/FULL JOIN <table> ON <condition>
      - Implicit: FROM t1 a, t2 b WHERE a.id = b.id  (Gap 14)
      - PBSELECT: JOIN(LEFT="t1.col" OP="=" RIGHT="t2.col")  (Gap 15)
    """
    joins = []
    seen: set = set()

    # Explicit JOIN ... ON
    for m in re.finditer(
        r"(INNER|LEFT|RIGHT|FULL|CROSS)?\s*JOIN\s+(\w+)\s+(?:\w+\s+)?ON\s+(.+?)(?=\s+(?:INNER|LEFT|RIGHT|FULL|CROSS|WHERE|ORDER|GROUP|HAVING|JOIN)|$)",
        sql, re.IGNORECASE
    ):
        join_type  = (m.group(1) or "INNER").upper()
        join_table = m.group(2).lower()
        condition  = re.sub(r"\s+", " ", m.group(3)).strip().rstrip(";").rstrip()
        key = f"{join_table}:{condition[:40]}"
        if key not in seen:
            seen.add(key)
            joins.append({"join_table": join_table, "join_type": join_type, "condition": condition})

    # Implicit comma joins: FROM t1 a, t2 b WHERE a.x = b.x  (Gap 14)
    from_m = re.search(
        r"FROM\s+(.+?)(?:\s+WHERE|\s+ORDER|\s+GROUP|\s+HAVING|$)",
        sql, re.IGNORECASE | re.DOTALL
    )
    if from_m:
        comma_tbls = re.findall(
            r"(\w+)\s+(\w+)(?=\s*,|\s+WHERE|\s*$)", from_m.group(1), re.IGNORECASE
        )
        if len(comma_tbls) > 1:
            alias_to_tbl = {a.lower(): t.lower() for t, a in comma_tbls if valid_table(t)}
            for cm in re.finditer(
                r"(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)", sql, re.IGNORECASE
            ):
                t1, c1, t2, c2 = (
                    cm.group(1).lower(), cm.group(2).lower(),
                    cm.group(3).lower(), cm.group(4).lower()
                )
                # resolve aliases to real table names
                rt1 = alias_to_tbl.get(t1, t1)
                rt2 = alias_to_tbl.get(t2, t2)
                if rt1 != rt2 and valid_table(rt2):
                    cond = f"{rt1}.{c1} = {rt2}.{c2}"
                    key  = f"{rt2}:{cond[:40]}"
                    if key not in seen:
                        seen.add(key)
                        joins.append({
                            "join_table": rt2,
                            "join_type":  "IMPLICIT",
                            "condition":  cond,
                        })

    # PBSELECT JOIN blocks (Gap 15)
    for m in re.finditer(
        r'JOIN\s*\(\s*LEFT\s*=\s*"([^"]+)"\s*OP[^R]*RIGHT\s*=\s*"([^"]+)"\s*\)',
        sql, re.IGNORECASE
    ):
        left  = m.group(1).lower()
        right = m.group(2).lower()
        if "." in right:
            join_table = right.split(".")[0]
            cond = f"{left} = {right}"
            key  = f"{join_table}:{cond[:40]}"
            if key not in seen:
                seen.add(key)
                joins.append({
                    "join_table": join_table,
                    "join_type":  "INNER",
                    "condition":  cond,
                })

    return joins


def extract_field_table_map(sql: str, tables: List[str]) -> List[Dict]:
    """
    Map each SELECT column to its source table.
    Handles: table.column, alias.column, bare column names.
    Also handles: SELECT 1 INTO :var, COUNT(*), implicit comma joins.
    Returns [{field, source_table}]
    """
    mappings = []

    # Gap 13: skip trivial single-value or aggregate-only selects
    if re.match(
        r"SELECT\s+(?:1|TOP\s+\d+\s+1|COUNT\s*\(|MAX\s*\(|MIN\s*\(|SUM\s*\()",
        sql.strip(), re.IGNORECASE
    ):
        return mappings

    # Build alias map: alias -> real_table
    # Allow single-char aliases (a, b, c) common in PB SQL
    alias_map: Dict[str, str] = {}
    for m in re.finditer(
        r"\b(?:FROM|JOIN)\s+(\w+)\s+(?:AS\s+)?([a-zA-Z]\w*)(?=\s)",
        sql, re.IGNORECASE
    ):
        tbl   = m.group(1).lower()
        alias = m.group(2).lower()
        if tbl != alias and valid_table(tbl):
            alias_map[alias] = tbl

    # Gap 14: also build alias map from implicit comma joins: FROM t1 a, t2 b
    from_m = re.search(
        r"FROM\s+(.+?)(?:\s+WHERE|\s+ORDER|\s+GROUP|\s+HAVING|$)",
        sql, re.IGNORECASE | re.DOTALL
    )
    if from_m:
        for tbl, alias in re.findall(
            r"(\w+)\s+(\w+)(?=\s*,|\s+WHERE|\s*$)", from_m.group(1), re.IGNORECASE
        ):
            if tbl.lower() != alias.lower() and valid_table(tbl):
                alias_map[alias.lower()] = tbl.lower()

    sel_m = re.search(r"SELECT\s+(.*?)\s+FROM", sql, re.IGNORECASE | re.DOTALL)
    if not sel_m:
        return mappings

    col_str = sel_m.group(1)
    # Strip INTO clause: SELECT col INTO :var FROM ...
    into_pos = col_str.upper().find(" INTO ")
    if into_pos != -1:
        col_str = col_str[:into_pos]

    for raw_col in col_str.split(","):
        raw_col = raw_col.strip()
        if not raw_col or raw_col in ("*", "1"):
            continue
        # Skip aggregate functions without alias
        if re.match(r"(?:COUNT|MAX|MIN|SUM|AVG)\s*\(", raw_col, re.IGNORECASE):
            continue
        # Strip AS alias
        as_m = re.match(r'^(.*?)\s+AS\s+(\w+)$', raw_col, re.IGNORECASE)
        col_expr = as_m.group(1).strip() if as_m else raw_col

        if "." in col_expr:
            parts        = col_expr.split(".")
            prefix       = parts[-2].lower().strip()
            col          = parts[-1].lower().strip()
            source_table = alias_map.get(prefix, prefix)
        else:
            col          = col_expr.lower().strip()
            source_table = tables[0] if tables else ""

        if col and len(col) > 1 and not col.startswith("("):
            mappings.append({"field": col, "source_table": source_table})
    return mappings

def derive_service_name(table: str) -> str:
    """
    Derive a microservice name from a table name.
    ap_vendor          → VendorService
    ap_vendor_address  → VendorAddressService
    mc_currency        → CurrencyService
    """
    # Strip known DB prefixes
    name = re.sub(r"^(ap_|mc_|gl_|ar_|po_|hr_|pr_|im_)", "", table, flags=re.IGNORECASE)
    # Convert snake_case to PascalCase
    pascal = "".join(w.capitalize() for w in name.split("_"))
    return f"{pascal}Service"


# ─────────────────────────────────────────────────────────────────────────────
# STATEMENT PATTERNS
# ─────────────────────────────────────────────────────────────────────────────

_STMT_PATS = [
    ("SELECT", re.compile(r"\bSELECT\b\s+.+?\bFROM\b\s+\w+.*?(?:;|$)", re.IGNORECASE | re.DOTALL)),
    ("UPDATE", re.compile(r"\bUPDATE\b\s+\w+\s+SET\b.*?(?:;|$)", re.IGNORECASE | re.DOTALL)),
    ("INSERT", re.compile(r"\bINSERT\b\s+INTO\s+\w+.*?(?:;|$)", re.IGNORECASE | re.DOTALL)),
    ("DELETE", re.compile(r"\bDELETE\b\s+FROM\s+\w+.*?(?:;|$)", re.IGNORECASE | re.DOTALL)),
]


def extract_sql_statements(content: str, filename: str) -> List[Dict]:
    queries, seen = [], set()
    for qtype, pat in _STMT_PATS:
        for m in pat.finditer(content):
            raw = m.group(0).strip()
            if ";" in raw:
                raw = raw[:raw.index(";") + 1].strip()
            sql = re.sub(r"\s+", " ", raw)
            if len(sql) < 12:
                continue
            if not is_real_sql(sql):
                continue
            sig = sql[:120]
            if sig in seen:
                continue
            seen.add(sig)
            tables = extract_tables_from_sql(sql)
            if not tables and qtype in ("SELECT", "DELETE"):
                continue
            tables    = extract_tables_from_sql(sql)
            field_map = extract_field_table_map(sql, tables)
            joins     = extract_join_conditions(sql)
            queries.append({
                "source":          filename,
                "sql":             sql,
                "query_type":      qtype,
                "tables":          tables,
                "columns":         extract_cols(sql, qtype),
                "parameters":      extract_params(sql),
                "join_conditions": joins,
                "field_table_map": field_map,
                "primary_table":   tables[0] if tables else "",
            })
    return queries


def extract_pbselect_field_table_map(pbsql: str) -> List[Dict]:
    """
    Extract field->table mapping from PBSELECT format.  (Gap 15)
    PBSELECT COLUMN(NAME="table.column") -> {field, source_table}
    """
    mappings = []
    seen: set = set()
    for m in re.finditer(
        r'COLUMN\s*\(\s*NAME\s*=\s*"([^"]+)"\s*\)', pbsql, re.IGNORECASE
    ):
        db_name = m.group(1)  # e.g. "ap_vendor.vendor_id"
        if "." in db_name:
            source_table = db_name.split(".")[0].lower()
            field        = db_name.split(".")[1].lower()
        else:
            source_table = ""
            field        = db_name.lower()
        key = f"{field}:{source_table}"
        if key not in seen and field:
            seen.add(key)
            mappings.append({"field": field, "source_table": source_table})
    return mappings


def parse_dw_sql(content: str, filename: str) -> List[Dict]:
    """Parse retrieve= SQL from a DataWindow (.srd) file."""
    m = re.search(r'retrieve\s*=\s*"((?:[^"~]|~.)*)"', content, re.IGNORECASE)
    if not m:
        return []
    raw_sql = clean_sql(m.group(1))
    upper = raw_sql.upper().strip()
    if upper.startswith("PBSELECT"):
        tables    = extract_tables_from_pbselect(raw_sql)
        qtype     = "PBSELECT"
        field_map = extract_pbselect_field_table_map(raw_sql)  # Gap 15
        joins     = extract_join_conditions(raw_sql)            # now parses PBSELECT JOIN
    else:
        qtype     = "SELECT" if "SELECT" in upper else "UNKNOWN"
        tables    = extract_tables_from_sql(raw_sql)
        field_map = extract_field_table_map(raw_sql, tables)
        joins     = extract_join_conditions(raw_sql)
    return [{
        "source":          filename,
        "sql":             raw_sql,
        "query_type":      qtype,
        "tables":          tables,
        "columns":         extract_cols(raw_sql, qtype if qtype != "PBSELECT" else ""),
        "parameters":      extract_params(raw_sql),
        "join_conditions": joins,
        "field_table_map": field_map,
        "primary_table":   tables[0] if tables else "",
    }]


# ─────────────────────────────────────────────────────────────────────────────
# PROCEDURE EXTRACTION
# ─────────────────────────────────────────────────────────────────────────────

_DECLARE_PAT = re.compile(
    r"DECLARE\s+\w+\s+PROCEDURE\s+FOR\s+(?:\w+\.)?(\w+)\s*(.*?);",
    re.IGNORECASE
)
_EXEC_PAT = re.compile(
    r"EXEC(?:UTE)?\s+(?:\w+\.)?(\w+)\s*(.*?);",
    re.IGNORECASE
)


def extract_procedures(content: str, filename: str) -> List[Dict]:
    procs: Dict[str, Dict] = {}
    for m in _DECLARE_PAT.finditer(content):
        name = m.group(1).lower()
        if not valid_proc(name):
            continue
        key = f"{name}:{filename}"
        procs[key] = {
            "name":        name,
            "called_from": filename,
            "parameters":  extract_params(m.group(2)),
            "source":      "DECLARE"
        }
    for m in _EXEC_PAT.finditer(content):
        name = m.group(1).lower()
        if not valid_proc(name):
            continue
        key = f"{name}:{filename}"
        if key not in procs:
            procs[key] = {
                "name":        name,
                "called_from": filename,
                "parameters":  extract_params(m.group(2)),
                "source":      "EXEC"
            }
    return list(procs.values())


# ─────────────────────────────────────────────────────────────────────────────
# FILE DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────

def find_pb_files(project_dir: str) -> List[str]:
    exts = {".srd", ".srw", ".sru", ".srf"}
    files = []
    for root, dirs, names in os.walk(project_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__MACOSX"]
        for n in names:
            if Path(n).suffix.lower() in exts:
                files.append(os.path.join(root, n))
    seen, unique = set(), []
    for f in files:
        b = os.path.basename(f)
        if b not in seen:
            seen.add(b)
            unique.append(f)
    return sorted(unique)


# ─────────────────────────────────────────────────────────────────────────────
# EXCEL REPORT GENERATOR
# ─────────────────────────────────────────────────────────────────────────────

class ExcelReportGenerator:
    HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    TITLE_FONT  = Font(name="Calibri", size=14, bold=True)
    BOLD_FONT   = Font(name="Calibri", size=11, bold=True)
    NORMAL_FONT = Font(name="Calibri", size=10)
    THIN_BORDER = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"),  bottom=Side(style="thin")
    )

    def _header_row(self, ws, row: int, headers: List[str]):
        for ci, h in enumerate(headers, 1):
            cell = ws.cell(row=row, column=ci, value=h)
            cell.font = self.HEADER_FONT
            cell.fill = self.HEADER_FILL
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = self.THIN_BORDER

    def _data_rows(self, ws, start: int, end: int, ncols: int):
        for r in range(start, end + 1):
            for c in range(1, ncols + 1):
                cell = ws.cell(row=r, column=c)
                cell.font = self.NORMAL_FONT
                cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
                cell.border = self.THIN_BORDER

    def _col_widths(self, ws, widths: List[int]):
        for idx, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(idx)].width = w

    def generate(self, result: Dict, output_path: str):
        wb = Workbook()

        # ── Sheet 1: Master Summary ──────────────────────────────────────────
        ws_sum = wb.active
        ws_sum.title = "Summary"
        ws_sum["A1"] = "SQL Discovery — Master Summary"
        ws_sum["A1"].font = self.TITLE_FONT
        ws_sum.merge_cells("A1:D1")
        ws_sum["A2"] = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        row = 4
        stats_data = [
            ("Total Tables",     len(result.get("tables", []))),
            ("Total Queries",    len(result.get("queries", []))),
            ("Total Procedures", len(result.get("procedures", []))),
        ]
        for label, val in stats_data:
            ws_sum.cell(row=row, column=1, value=label).font = self.BOLD_FONT
            ws_sum.cell(row=row, column=2, value=val)
            row += 1

        # Query type breakdown
        row += 1
        ws_sum.cell(row=row, column=1, value="Queries by Type:").font = self.BOLD_FONT
        row += 1
        qtype_counts: Dict[str, int] = {}
        for q in result.get("queries", []):
            qtype_counts[q.get("query_type", "UNKNOWN")] = \
                qtype_counts.get(q.get("query_type", "UNKNOWN"), 0) + 1
        for qt, cnt in sorted(qtype_counts.items()):
            ws_sum.cell(row=row, column=1, value=f"  {qt}")
            ws_sum.cell(row=row, column=2, value=cnt)
            row += 1

        self._col_widths(ws_sum, [30, 15, 30, 15])

        # ── Sheet 2: Tables ──────────────────────────────────────────────────
        ws_tbl = wb.create_sheet("Tables")
        ws_tbl["A1"] = "All Tables Referenced"
        ws_tbl["A1"].font = self.TITLE_FONT
        headers = ["#", "Table Name"]
        self._header_row(ws_tbl, 3, headers)
        row = 4
        data_start = row
        for idx, tbl in enumerate(sorted(result.get("tables", [])), 1):
            ws_tbl.cell(row=row, column=1, value=idx)
            ws_tbl.cell(row=row, column=2, value=tbl)
            row += 1
        if row > data_start:
            self._data_rows(ws_tbl, data_start, row - 1, len(headers))
        self._col_widths(ws_tbl, [6, 40])
        ws_tbl.freeze_panes = "A4"

        # ── Sheet 3: Queries ─────────────────────────────────────────────────
        ws_q = wb.create_sheet("Queries")
        ws_q["A1"] = "All SQL Queries"
        ws_q["A1"].font = self.TITLE_FONT
        q_headers = [
            "#", "Source File", "Query Type", "Tables",
            "Columns", "Parameters", "SQL (truncated)"
        ]
        self._header_row(ws_q, 3, q_headers)
        row = 4
        data_start = row
        for idx, q in enumerate(result.get("queries", []), 1):
            ws_q.cell(row=row, column=1, value=idx)
            ws_q.cell(row=row, column=2, value=q.get("source", ""))
            ws_q.cell(row=row, column=3, value=q.get("query_type", ""))
            ws_q.cell(row=row, column=4, value=", ".join(q.get("tables", [])))
            ws_q.cell(row=row, column=5, value=", ".join(q.get("columns", [])[:20]))
            ws_q.cell(row=row, column=6, value=", ".join(q.get("parameters", [])))
            ws_q.cell(row=row, column=7, value=(q.get("sql") or "")[:500])
            row += 1
        if row > data_start:
            self._data_rows(ws_q, data_start, row - 1, len(q_headers))
        self._col_widths(ws_q, [5, 30, 12, 30, 40, 25, 80])
        ws_q.freeze_panes = "A4"

        # ── Sheet 4: Procedures ──────────────────────────────────────────────
        ws_p = wb.create_sheet("Procedures")
        ws_p["A1"] = "All Stored Procedure Calls"
        ws_p["A1"].font = self.TITLE_FONT
        p_headers = ["#", "Procedure Name", "Called From", "Parameters", "Source"]
        self._header_row(ws_p, 3, p_headers)
        row = 4
        data_start = row
        for idx, p in enumerate(result.get("procedures", []), 1):
            ws_p.cell(row=row, column=1, value=idx)
            ws_p.cell(row=row, column=2, value=p.get("name", ""))
            ws_p.cell(row=row, column=3, value=p.get("called_from", ""))
            ws_p.cell(row=row, column=4, value=", ".join(p.get("parameters", [])))
            ws_p.cell(row=row, column=5, value=p.get("source", ""))
            row += 1
        if row > data_start:
            self._data_rows(ws_p, data_start, row - 1, len(p_headers))
        self._col_widths(ws_p, [5, 35, 35, 30, 10])
        ws_p.freeze_panes = "A4"

        wb.save(output_path)
        print(f"📊 Excel saved: {output_path}  ({os.path.getsize(output_path):,} bytes)")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def generate_sql_discovery(
    project_dir: str,
    output_json: str = "sql_discovery.json",
    output_xlsx: str = "sql_discovery.xlsx"
) -> Dict:
    print(f"SQL Discovery — scanning {project_dir}")
    files = find_pb_files(project_dir)
    print(f"  Found {len(files)} PB files")

    all_tables: Set[str] = set()
    all_queries: List[Dict] = []
    all_procs: List[Dict] = []

    for fp in files:
        filename = os.path.basename(fp)
        ext = Path(fp).suffix.lower()
        try:
            content = read_file(fp)
        except Exception as e:
            print(f"  ❌ {filename} — read error: {e}")
            continue

        if ext == ".srd":
            queries = parse_dw_sql(content, filename)
        else:
            queries = extract_sql_statements(content, filename)

        for q in queries:
            all_tables.update(q.get("tables", []))
        all_queries.extend(queries)
        all_procs.extend(extract_procedures(content, filename))

    # Also pull tables from dbname="table.col" attributes
    for fp in files:
        try:
            content = read_file(fp)
            for m in re.finditer(r'dbname="(\w+)\.\w+"', content):
                if valid_table(m.group(1)):
                    all_tables.add(m.group(1).lower())
        except Exception:
            pass

    # Dedup procedures and add owning_service (Gap 16)
    seen_p: set = set()
    deduped: List[Dict] = []
    for p in all_procs:
        k = f"{p['name']}:{p['called_from']}"
        if k not in seen_p:
            seen_p.add(k)
            # Derive owning_service from procedure name prefix
            # e.g. cm_payment_notification_sent → first 2-3 letters map to domain
            pname = p.get("name", "")
            pm = re.match(r"^([a-z]{2,3})_", pname)
            p["owning_service"] = derive_service_name(pm.group(1) + "_proc") if pm else ""
            deduped.append(p)

    # Build table → service map for every discovered table
    table_service_map = {
        tbl: derive_service_name(tbl)
        for tbl in sorted(all_tables)
    }

    result: Dict = {
        "tables":            sorted(all_tables),
        "table_service_map": table_service_map,
        "queries":           all_queries,
        "procedures":        deduped,
    }

    print(f"\n  Tables:     {len(result['tables'])}")
    print(f"  Queries:    {len(result['queries'])}")
    print(f"  Procedures: {len(result['procedures'])}")

    # ── Write JSON ────────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(os.path.abspath(output_json)), exist_ok=True)
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    print(f"💾 JSON saved: {output_json}  ({os.path.getsize(output_json):,} bytes)")

    # ── Write Excel ───────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(os.path.abspath(output_xlsx)), exist_ok=True)
    ExcelReportGenerator().generate(result, output_xlsx)

    return result


if __name__ == "__main__":
    generate_sql_discovery(
        project_dir="/Users/netraballolli/Documents/Discovery/pb_source /GL",
        output_json="sql_discovery.json",
        output_xlsx="sql_discovery.xlsx",
    )
