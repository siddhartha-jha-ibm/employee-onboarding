"""
generatepb.py  (v8-enhanced)
=============================
Produces pb_objects.json + pb_objects_analysis.xlsx from a PowerBuilder
project directory.

Incorporates enhancements from datawindow_metrics_v8.py:
  - Tag extraction from all control types
  - ControlInfo with tag field
  - FunctionInfo with parameters list
  - Lookup reference extraction (Open/OpenWithParm + DataObject=)
  - Window dimensions extraction
  - Richer event analysis (sql_operations, function_calls, variables)
  - Excel output:
      · Master Summary sheet  (file-level counts)
      · Windows sheet         (window controls + functions)
      · User Objects sheet    (methods + SQL statements)
      · Functions sheet       (global functions / structures)
      · Events sheet          (all events across all files)

Extensions handled:
  .srw → parse_window       (events, controls, functions, DW refs)
  .sru → parse_user_object  (methods, constants, SQL, classify_sru)
  .srf → parse_function     (PBExportComments purpose)
  .srs → parse_structure    (fields with type/name/comment)

Bug fixes retained from original:
  1. TYPE_PATTERN phantom components → require `within <parent>`
  2. dataobject= duplicate mutation → assign once per control id
  3. Greedy DOTALL table names → per-statement non-greedy + skip-word filter
  4. Event name truncation → full `event ... end event` block regex
  5. .srf/.srs had no dedicated parsers → parse_function / parse_structure
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ─────────────────────────────────────────────────────────────────────────────
# SQL HELPERS
# ─────────────────────────────────────────────────────────────────────────────

_SQL_OPS = [
    ("select", re.compile(r"\bSELECT\b.*?\bFROM\s+(\w+)", re.IGNORECASE | re.DOTALL)),
    ("update", re.compile(r"\bUPDATE\s+(\w+)\s+SET\b", re.IGNORECASE)),
    ("insert", re.compile(r"\bINSERT\s+INTO\s+(\w+)\b", re.IGNORECASE)),
    ("delete", re.compile(r"\bDELETE\s+FROM\s+(\w+)\b", re.IGNORECASE)),
]
_SKIP_SQL = {
    "the", "by", "and", "or", "not", "null", "into", "where", "set", "as", "on", "in",
    "from", "all", "any", "case", "when", "then", "else", "end", "is"
}


def extract_sql_operations(code: str) -> List[Dict]:
    ops, seen = [], set()
    for op, pat in _SQL_OPS:
        for m in pat.finditer(code):
            t = m.group(1).lower()
            if t in _SKIP_SQL or len(t) <= 2:
                continue
            k = f"{op}:{t}"
            if k not in seen:
                seen.add(k)
                ops.append({"operation": op, "table": t})
    return ops


def extract_function_calls(code: str) -> List[str]:
    kw = {
        "if", "for", "while", "choose", "case", "return", "integer", "string",
        "boolean", "end", "then", "else", "loop"
    }
    seen, out = set(), []
    for m in re.finditer(r"(\w+)\s*\(", code):
        n = m.group(1)
        if n.lower() not in kw and len(n) > 2 and n not in seen:
            seen.add(n)
            out.append(n)
    return out


def extract_variables(code: str) -> List[str]:
    VAR = re.compile(
        r"^(?:integer|int|string|boolean|blob|date|datetime|time|"
        r"decimal|dec|double|long|real)\s+([a-zA-Z0-9_,\s]+)",
        re.IGNORECASE
    )
    out, seen = [], set()
    for line in code.split("\n"):
        line = line.strip()
        if not line or line.startswith("//"):
            continue
        m = VAR.match(line)
        if m:
            for v in m.group(1).split(","):
                v = v.strip().split("=")[0].strip()
                if v and v not in seen:
                    seen.add(v)
                    out.append(v)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# FILE READER
# ─────────────────────────────────────────────────────────────────────────────

def read_file(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    if raw[:2] == b"\xff\xfe":
        return raw.decode("utf-16-le", errors="replace").replace("\r\n", "\n").replace("\r", "\n")
    if raw[:2] == b"\xfe\xff":
        return raw.decode("utf-16-be", errors="replace").replace("\r\n", "\n").replace("\r", "\n")
    if raw[:3] == b"\xef\xbb\xbf":
        return raw[3:].decode("utf-8", errors="replace").replace("\r\n", "\n").replace("\r", "\n")
    try:
        text = raw.decode("utf-8", errors="strict")
        if "\x00" in text:
            text = raw.decode("utf-16", errors="replace")
    except UnicodeDecodeError:
        text = raw.decode("cp1252", errors="replace")
    return text.replace("\r\n", "\n").replace("\r", "\n")


# ─────────────────────────────────────────────────────────────────────────────
# SRU CLASSIFIER
# ─────────────────────────────────────────────────────────────────────────────

def classify_sru(r: dict) -> dict:
    methods    = r.get("methods", [])
    constants  = r.get("constants", [])
    sql_stmts  = r.get("sql_statements", [])
    line_count = r.get("line_count", 0)
    inherits   = r.get("inherits_from", "") or ""
    mnames     = [m["name"].lower() for m in methods]

    numeric = sum(1 for n in mnames if re.search(r"\d{3,}", n))
    has_embedded_sql = len(sql_stmts) > 0

    if len(methods) >= 5 and numeric >= len(methods) * 0.6 and has_embedded_sql:
        r["category"]    = "dynamic_sql_package"
        r["description"] = f"SQL package — {len(methods)} stored procedure wrappers"
        return r

    if len(constants) >= 10 and len(methods) <= 3 and not sql_stmts:
        r["category"]    = "settings"
        r["description"] = f"Configuration object — {len(constants)} constants, no SQL"
        return r

    audit = [n for n in mnames if re.search(r"audit|log|register|history|track|record|monitor", n)]
    if len(audit) >= 2:
        r["category"]    = "audit_service"
        r["description"] = f"Audit/modification register — {len(audit)} audit methods: {', '.join(audit[:3])}"
        return r

    dw_m = [n for n in mnames if re.search(r"update|retrieve|save|delete|insert|refresh|reset", n)]
    if re.search(r"datawindow|dw|std_dw", inherits, re.IGNORECASE) or len(dw_m) >= 3:
        r["category"]    = "framework_datawindow"
        r["description"] = f"DataWindow base class — {len(dw_m)} data methods: {', '.join(dw_m[:3])}"
        return r

    nav = [n for n in mnames if re.search(
        r"navigate|move|scroll|next|prev|first|last|button|enable|visible|show|hide", n
    )]
    if len(nav) >= 2 and not sql_stmts:
        r["category"]    = "framework_ui"
        r["description"] = f"UI/navigation object — {len(nav)} navigation methods"
        return r

    if len(methods) >= 15 and sql_stmts and line_count >= 500:
        r["category"]    = "framework_core"
        r["description"] = f"Core framework object — {len(methods)} methods, {line_count} lines"
        return r

    if sql_stmts and len(nav) == 0:
        r["category"]    = "data_service"
        r["description"] = f"Data service — {len(sql_stmts)} SQL statements, no UI code"
        return r

    if len(nav) >= 1 and not sql_stmts:
        r["category"]    = "ui_helper"
        r["description"] = f"UI helper — {len(nav)} navigation methods, no DB code"
        return r

    r["category"]    = "user_object"
    r["description"] = f"User object — {len(methods)} methods"
    return r


# ─────────────────────────────────────────────────────────────────────────────
# PB BUILTINS
# ─────────────────────────────────────────────────────────────────────────────

PB_BUILTINS = {
    "window", "nonvisualobject", "userobject", "datawindow", "commandbutton",
    "statictext", "singlelineedit", "multilineedit", "dropdownlistbox", "checkbox",
    "radiobutton", "groupbox", "picture", "tab", "tabpage", "treeview", "listview",
    "datastore", "structure", "function_object", "oleobject"
}


# ─────────────────────────────────────────────────────────────────────────────
# BASE RESULT
# ─────────────────────────────────────────────────────────────────────────────

def base(file_path: str, obj_type: str, name: str) -> dict:
    return {
        "file":              file_path,
        "object_type":       obj_type,
        "name":              name,
        "components":        [],
        "events":            [],
        "inherits_from":     None,
        "functions":         [],
        "functions_called":  [],
        "datawindows_used":  [],
        "dynamic_sql_calls": [],
        "security_events":   [],
        "validations":       [],
        "message_boxes":     [],
        "variables":         [],
        "stored_procedures": [],
        "comments":          [],
        # v8-enhanced fields
        "lookup_references": [],
        "width":             0,
        "height":            0,
        "tag":               "",
        # new fields (Gaps 1-6)
        "controls_detail":   [],
        "buttons":           [],
        "inherited_events":  [],
        "functions_detail":  [],
    }


# ─────────────────────────────────────────────────────────────────────────────
# SHARED PARSERS
# ─────────────────────────────────────────────────────────────────────────────

def parse_events(content: str, result: dict):
    """Parse full event blocks with rich analysis."""
    for m in re.finditer(
        r"event\s+(?:(\w+)::)?(\w+)\s*;([\s\S]*?)end event",
        content, re.IGNORECASE
    ):
        code = m.group(3).strip()
        if len(code) <= 10:
            continue
        result["events"].append({
            "event_name":    m.group(2),
            "script_length": len(code),
            "script":        code,
            "analysis": {
                "sql_operations": extract_sql_operations(code),
                "function_calls": extract_function_calls(code),
                "variables":      extract_variables(code),
            },
            "has_sql": bool(re.search(
                r"\b(SELECT|INSERT|UPDATE|DELETE|EXECUTE|DECLARE)\b",
                code, re.IGNORECASE
            )),
            "has_messagebox": "MessageBox" in code,
            "has_validation": bool(re.search(
                r"\b(validate|validation|ue_item_validation)\b",
                code, re.IGNORECASE
            )),
        })


def _extract_tag(content: str, ctrl_name: str) -> str:
    """Extract .tag value for a named control (v8 enhancement)."""
    tag_match = re.search(
        rf'{re.escape(ctrl_name)}\.tag\s*=\s*"([^"]*)"',
        content, re.IGNORECASE
    )
    return tag_match.group(1) if tag_match else ""


def _extract_window_dimensions(content: str):
    """Extract window width and height (v8 enhancement)."""
    w = h = 0
    mw = re.search(r'\bwidth\s*=\s*(\d+)', content, re.IGNORECASE)
    mh = re.search(r'\bheight\s*=\s*(\d+)', content, re.IGNORECASE)
    if mw:
        w = int(mw.group(1))
    if mh:
        h = int(mh.group(1))
    return w, h


def _extract_lookup_references(content: str) -> List[str]:
    """Extract OpenWithParm/Open calls and DataObject= references (v8 enhancement)."""
    lookups = []
    for m in re.finditer(r'Open(?:WithParm)?\s*\(\s*(\w+)', content, re.IGNORECASE):
        lookups.append(m.group(1))
    for m in re.finditer(r'(\w+)\.DataObject\s*=', content, re.IGNORECASE):
        lookups.append(m.group(1))
    return list(set(lookups))[:20]



# ─────────────────────────────────────────────────────────────────────────────
# CONTROL DETAIL EXTRACTOR  (Gaps 1, 2, 5)
# ─────────────────────────────────────────────────────────────────────────────

_BUTTON_BASES   = {"commandbutton", "button", "picturebutton"}
_LABEL_BASES    = {"statictext"}
_INPUT_BASES    = {"singlelineedit", "multilineedit"}
_DROPDOWN_BASES = {"dropdownlistbox", "dropdownpicturelist"}
_ALL_CTRL_BASES = (
    _BUTTON_BASES | _LABEL_BASES | _INPUT_BASES | _DROPDOWN_BASES |
    {"checkbox", "radiobutton", "groupbox", "tab", "tabpage", "datawindow"}
)


def _ctrl_text(block: str) -> str:
    for pat in [r'text\s*=\s*"([^"]*)"', r"text\s*=\s*'([^']*)'"]:
        m = re.search(pat, block, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    return ""


def _ctrl_int(block: str, attr: str) -> int:
    m = re.search(rf"\b{attr}\s*=\s*(\d+)", block, re.IGNORECASE)
    return int(m.group(1)) if m else 0


def _ctrl_visible_expr(block: str) -> str:
    m = re.search(r'visible\s*=\s*"([^"]*)"', block, re.IGNORECASE)
    if m:
        expr = m.group(1).strip()
        if expr not in ("0", "1", "true", "false", ""):
            return expr
    return ""


def _ctrl_protect_expr(block: str) -> str:
    m = re.search(r'protect\s*=\s*"([^"]*)"', block, re.IGNORECASE)
    if m:
        expr = m.group(1).strip()
        if expr not in ("0", "1", "true", "false", ""):
            return expr
    return ""


def _ctrl_events(block: str) -> List[Dict]:
    """Extract per-control event scripts (clicked, getfocus etc.)."""
    evts = []
    for m in re.finditer(
        r"event\s+(\w+)\s*;([\s\S]*?)end\s+event",
        block, re.IGNORECASE
    ):
        ename  = m.group(1).lower()
        script = m.group(2).strip()
        if len(script) < 5:
            continue
        evts.append({
            "event_name":    ename,
            "script_length": len(script),
            "script":        script,
            "has_sql":       bool(re.search(
                r"\b(SELECT|INSERT|UPDATE|DELETE|EXECUTE|DECLARE)\b",
                script, re.IGNORECASE)),
            "has_messagebox": "MessageBox" in script,
        })
    return evts


def extract_controls_detail(content: str) -> List[Dict]:
    """
    Extract detailed control info from .srw:
    buttons, labels, inputs — with label, position, visibility expr,
    protect expr, tabsequence, and per-control events.
    (Gaps 1, 2, 5)
    """
    controls = []
    seen: set = set()

    ctrl_pat = re.compile(
        r"type\s+(\w+)\s+from\s+(\w+)\s+within\s+\w+"
        r"([\s\S]*?)"
        r"end\s+type",
        re.IGNORECASE
    )

    for m in ctrl_pat.finditer(content):
        cname = m.group(1)
        cbase = m.group(2).lower()
        cblock= m.group(3)

        if cbase not in _ALL_CTRL_BASES:
            continue
        if cname in seen:
            continue
        seen.add(cname)

        if cbase in _BUTTON_BASES:
            kind = "button"
        elif cbase in _LABEL_BASES:
            kind = "label"
        elif cbase in _INPUT_BASES:
            kind = "input"
        elif cbase in _DROPDOWN_BASES:
            kind = "dropdown"
        elif cbase == "groupbox":
            kind = "groupbox"
        elif cbase in ("checkbox",):
            kind = "checkbox"
        elif cbase in ("radiobutton",):
            kind = "radiobutton"
        else:
            kind = cbase

        controls.append({
            "name":         cname,
            "kind":         kind,
            "base_type":    cbase,
            "label":        _ctrl_text(cblock),
            "visible_expr": _ctrl_visible_expr(cblock),
            "protect_expr": _ctrl_protect_expr(cblock),
            "x":            _ctrl_int(cblock, "x"),
            "y":            _ctrl_int(cblock, "y"),
            "width":        _ctrl_int(cblock, "width"),
            "height":       _ctrl_int(cblock, "height"),
            "tabsequence":  _ctrl_int(cblock, "tabsequence"),
            "tag":          _extract_tag(content, cname),
            "events":       _ctrl_events(cblock),
        })

    return controls


def extract_all_message_boxes(content: str) -> List[Dict]:
    """
    Extract ALL MessageBox calls from entire .srw content including
    embedded message IDs.  (Gap 4)
    """
    msgs = []
    seen: set = set()

    # Standard MessageBox("title", "text")
    for m in re.finditer(
        r'MessageBox\s*\(\s*["\']((?:[^"\'\\]|\\.)*)["\']\s*,\s*["\']((?:[^"\'\\]|\\.)*)',
        content, re.IGNORECASE
    ):
        title = m.group(1)[:100]
        msg   = m.group(2)[:300]
        key   = f"{title[:30]}:{msg[:30]}"
        if key not in seen:
            seen.add(key)
            msgs.append({"title": title, "message": msg})

    # Message ID references (4-5 digit numbers in context of message calls)
    for m in re.finditer(r'\bMessageLabel\w*\s*\(.*?(\d{4,5})', content, re.IGNORECASE):
        mid = m.group(1)
        key = f"msgid:{mid}"
        if key not in seen:
            seen.add(key)
            ctx_s = max(0, m.start()-40)
            ctx_e = min(len(content), m.end()+80)
            ctx   = content[ctx_s:ctx_e].replace("\n", " ").strip()
            msgs.append({"title": f"MessageID_{mid}", "message": ctx[:200]})

    return msgs


def merge_inherited_events(result: dict, all_results: dict) -> List[Dict]:
    """
    Collect parent events not overridden in the child window.
    (Gap 3)
    """
    inherited = []
    parent_name = result.get("inherits_from", "")
    visited: set = set()
    child_events = {e.get("event_name","") for e in result.get("events", [])}

    while parent_name and parent_name not in visited:
        visited.add(parent_name)
        parent = (all_results.get(parent_name + ".srw") or
                  all_results.get(parent_name))
        if not parent:
            break
        for ev in parent.get("events", []):
            en = ev.get("event_name", "")
            if en and en not in child_events:
                inherited.append({
                    **ev,
                    "inherited":      True,
                    "inherited_from": parent_name,
                })
        parent_name = parent.get("inherits_from", "")

    return inherited


def deduplicate_functions_detail(fns: List[Dict]) -> List[Dict]:
    """Remove duplicate function signatures. (Gap 6)"""
    seen: set = set()
    out = []
    for f in fns:
        key = f"{f.get('name','')}:{f.get('params','')}:{f.get('return_type','')}"
        if key not in seen:
            seen.add(key)
            out.append(f)
    return out


def parse_common(content: str, result: dict):
    """Shared parsing: functions, calls, SQL calls, DW refs, security, messages, variables."""
    # Functions defined
    seen_f: set = set()
    for m in re.finditer(
        r"public\s+(?:function|subroutine)\s+(?:\w+\s+)?(\w+)\s*\(",
        content
    ):
        f = m.group(1)
        if f not in seen_f:
            seen_f.add(f)
            result["functions"].append(f)

    # Functions called (object.method)
    seen_c: set = set()
    for m in re.finditer(r"(\w+)\.(\w+)\s*\(", content):
        obj, fn = m.group(1), m.group(2)
        if len(fn) < 3:
            continue
        if obj.lower() in {"this", "parent", "super", "sqlca", "sqlda", "error", "message", "gnv_app"}:
            continue
        k = f"{obj}.{fn}"
        if k not in seen_c:
            seen_c.add(k)
            result["functions_called"].append({"object": obj, "function": fn})

    # Dynamic SQL calls (package.uf_proc_xxx)
    for m in re.finditer(r"(\w+)\.(uf_proc_\w+|\w*proc\w*)\s*\(", content, re.IGNORECASE):
        pkg, proc = m.group(1), m.group(2)
        if pkg.lower() in {"this", "parent", "super"}:
            continue
        result["dynamic_sql_calls"].append({"package": pkg, "procedure": proc})

    # Stored procedures
    for m in re.finditer(
        r"DECLARE\s+\w+\s+PROCEDURE\s+FOR\s+(?:dbo\.)?(\w+)", content, re.IGNORECASE
    ):
        result["stored_procedures"].append(m.group(1))

    # DataWindow references
    dw: set = set()
    for m in re.finditer(
        r'(?:dataobject|DataObject)\s*=\s*["\'](\w+)["\']', content, re.IGNORECASE
    ):
        dw.add(m.group(1))
    for m in re.finditer(
        r"uf_Set_DataObject\s*\([^,]+,\s*['\"](\w+)['\"]", content, re.IGNORECASE
    ):
        dw.add(m.group(1))
    result["datawindows_used"] = sorted(dw)

    # Security/audit events
    for m in re.finditer(
        r'(\w*(?:log|audit|security|track|record|monitor)\w*)\s*\(\s*["\']([^"\']+)["\']',
        content, re.IGNORECASE
    ):
        result["security_events"].append({"function": m.group(1), "message": m.group(2)})

    # MessageBox calls
    for m in re.finditer(
        r'MessageBox\s*\(\s*["\']([^"\']+)["\']\s*,\s*["\']([^"\']*)',
        content, re.IGNORECASE
    ):
        result["message_boxes"].append({"title": m.group(1), "message": m.group(2)[:200]})

    # Instance variables
    for m in re.finditer(
        r"^(?:Private:|Protected:|Public:)?\s*(?:constant\s+)?"
        r"(string|long|boolean|integer|decimal|datetime|w_\w+)\s+(\w+)",
        content, re.IGNORECASE | re.MULTILINE
    ):
        v = m.group(2)
        if v.startswith(("i", "is_", "ib_", "il_", "iw_")):
            result["variables"].append({"type": m.group(1), "name": v})

    # Key comments
    for m in re.finditer(
        r"(?:TFS\s*#?\s*\d+|Design\s+Change\s+\d+|Purpose\s*:\s*[^\n]+)",
        content, re.IGNORECASE
    ):
        result["comments"].append(m.group(0).strip()[:150])


# ─────────────────────────────────────────────────────────────────────────────
# .srw PARSER
# ─────────────────────────────────────────────────────────────────────────────

def parse_window(file_path: str, content: str) -> dict:
    stem = Path(file_path).stem
    r = base(file_path, "window", stem)

    m = re.search(r"global\s+type\s+\w+\s+from\s+(\w+)", content)
    if m:
        r["inherits_from"] = m.group(1)

    # Window dimensions — width/height (consistent naming, Gap 7)
    r["width"], r["height"] = _extract_window_dimensions(content)

    # Controls — require `within <parent>` to avoid method signature false positives
    seen_comps: set = set()
    assigned: set = set()
    for m in re.finditer(r"type\s+(\w+)\s+from\s+(\w+)\s+within\s+(\w+)", content, re.IGNORECASE):
        cid, ctype, cpar = m.group(1).lower(), m.group(2).lower(), m.group(3).lower()
        if cid == stem.lower():
            continue
        k = f"{cid}:{ctype}"
        if k not in seen_comps:
            seen_comps.add(k)
            # v8: extract tag for each control
            tag_val = _extract_tag(content, m.group(1))
            r["components"].append({
                "type":   ctype,
                "id":     cid,
                "parent": cpar,
                "tag":    tag_val,
            })

    # dataobject= linkage (assign once per control)
    for m in re.finditer(
        r'(?:dataobject|DataObject)\s*=\s*["\'](\w+)["\']', content, re.IGNORECASE
    ):
        dw_name = m.group(1).lower()
        for comp in r["components"]:
            if comp.get("id", "") not in assigned:
                comp["type"] = "datawindow"
                comp["id"] = dw_name
                assigned.add(comp["id"])
                break

    parse_events(content, r)

    # Field validations (CHOOSE CASE)
    for m in re.finditer(
        r'CASE\s+["\'](\w+)["\']\s*\n([\s\S]*?)(?=\n\s*CASE\s+["\']|\n\s*END\s+CHOOSE)',
        content, re.IGNORECASE
    ):
        cc = m.group(2)
        if len(cc) > 20:
            r["validations"].append({
                "field":       m.group(1),
                "has_error":   bool(re.search(r"error", cc, re.IGNORECASE)),
                "has_license": bool(re.search(r"uf_is_license", cc, re.IGNORECASE)),
                "code_length": len(cc),
            })

    # v8: Lookup references
    r["lookup_references"] = _extract_lookup_references(content)

    parse_common(content, r)

    # Gap 1+2+5: Extract controls with events and visibility
    r["controls_detail"] = extract_controls_detail(content)
    r["buttons"] = [
        {"name": c["name"], "label": c["label"],
         "visible_expr": c["visible_expr"], "events": c["events"]}
        for c in r["controls_detail"] if c["kind"] == "button"
    ]

    # Gap 4: All MessageBox calls including message IDs
    r["message_boxes"] = extract_all_message_boxes(content)

    # Gap 6: Deduplicate functions_detail
    r["functions_detail"] = deduplicate_functions_detail(
        r.get("functions_detail", [])
    )

    # Summary counts
    ctrl_types: Dict[str, int] = {}
    for comp in r["components"]:
        ct = comp.get("type", "unknown")
        ctrl_types[ct] = ctrl_types.get(ct, 0) + 1
    for ctrl in r["controls_detail"]:
        k = ctrl["kind"]
        ctrl_types[k] = ctrl_types.get(k, 0) + 1
    r["control_type_counts"] = ctrl_types
    r["total_controls"]      = len(r["components"]) + len(r["controls_detail"])
    r["total_functions"]     = len(r["functions"])
    r["total_events"]        = len(r["events"])

    return r


# ─────────────────────────────────────────────────────────────────────────────
# .sru PARSER
# ─────────────────────────────────────────────────────────────────────────────

def parse_user_object(file_path: str, content: str) -> dict:
    stem = Path(file_path).stem
    r = base(file_path, "userobject", stem)
    r.update({
        "methods":        [],
        "constants":      [],
        "structures":     [],
        "sql_statements": [],
        "line_count":     content.count("\n") + 1,
        "category":       None,
        "description":    None,
    })

    m = re.search(r"global\s+type\s+\w+\s+from\s+(\w+)", content)
    if m:
        r["inherits_from"] = m.group(1)

    # Methods with full body analysis
    method_pat = re.compile(
        r"(public\s+(?:function|subroutine)\s+(?:\w+\s+)?(\w+)\s*\(([^)]*)\))"
        r"([\s\S]*?)"
        r"(?=public\s+(?:function|subroutine)|end\s+(?:function|subroutine)|$)",
        re.IGNORECASE
    )
    for m in method_pat.finditer(content):
        params, body = m.group(3).strip(), m.group(4).strip()
        # v8: richer method analysis
        r["methods"].append({
            "name":           m.group(2),
            "params":         params[:200],
            "has_ref_params": bool(re.search(r"\bref\b", params, re.IGNORECASE)),
            "has_sql":        bool(re.search(
                r"\b(SELECT|INSERT|UPDATE|DELETE|EXECUTE|DECLARE)\b",
                body, re.IGNORECASE
            )),
            "sql_operations": extract_sql_operations(body),
            "line_count":     body.count("\n") + 1,
        })

    # Constants
    for m in re.finditer(r"constant\s+(\w+)\s+(\w+)\s*=\s*([^\n]+)", content, re.IGNORECASE):
        r["constants"].append({
            "type":  m.group(1),
            "name":  m.group(2),
            "value": m.group(3).strip()[:100],
        })

    # Embedded SQL
    for m in re.finditer(
        r"\b(SELECT|INSERT\s+INTO|UPDATE\s+\w+\s+SET|DELETE\s+FROM)\b[^;]{10,}",
        content, re.IGNORECASE
    ):
        r["sql_statements"].append(m.group(0)[:300])

    # Internal structures
    for m in re.finditer(r"type\s+(\w+)\s+from\s+structure", content):
        r["structures"].append(m.group(1))

    # Security events
    for m in re.finditer(
        r'(\w*(?:log|audit|security|track|record|monitor)\w*)\s*\(\s*["\']([^"\']+)["\']',
        content, re.IGNORECASE
    ):
        r["security_events"].append({"function": m.group(1), "message": m.group(2)})

    # Stored procedures
    for m in re.finditer(
        r"DECLARE\s+\w+\s+PROCEDURE\s+FOR\s+(?:dbo\.)?(\w+)", content, re.IGNORECASE
    ):
        r["stored_procedures"].append(m.group(1))

    # v8: Lookup references
    r["lookup_references"] = _extract_lookup_references(content)

    return classify_sru(r)


# ─────────────────────────────────────────────────────────────────────────────
# .srf PARSER
# ─────────────────────────────────────────────────────────────────────────────

def parse_function(file_path: str, content: str) -> dict:
    stem = Path(file_path).stem
    r = {
        "file":        file_path,
        "object_type": "function",
        "name":        stem,
        "components":  [],
        "events":      [],
        "purpose":     None,
        "parameters":  [],
        "return_type": "",
    }
    m = re.search(r"\$PBExportComments\$(.+)", content)
    if m:
        r["purpose"] = m.group(1).strip()
    if re.search(r"global\s+type\s+\w+\s+from\s+function_object", content):
        r["object_type"] = "global_function"

    # v8: extract function signature
    sig = re.search(
        r"(public|private|protected)?\s*(function|subroutine)\s+(\w+)\s+(\w+)\s*\(([^)]*)\)",
        content, re.IGNORECASE
    )
    if sig:
        r["return_type"] = sig.group(3)
        r["parameters"] = [p.strip() for p in sig.group(5).split(",") if p.strip()]

    return r


# ─────────────────────────────────────────────────────────────────────────────
# .srs PARSER
# ─────────────────────────────────────────────────────────────────────────────

def parse_structure(file_path: str, content: str) -> dict:
    stem = Path(file_path).stem
    r = {
        "file":        file_path,
        "object_type": "structure",
        "name":        stem,
        "components":  [],
        "events":      [],
        "purpose":     None,
        "fields":      [],
    }
    m = re.search(r"\$PBExportComments\$(.+)", content)
    if m:
        r["purpose"] = m.group(1).strip()
    for m in re.finditer(
        r'\t(\w+)\s+(\w+)\s+(?:descriptor\s+"comment"\s*=\s*"([^"]+)")?',
        content
    ):
        if m.group(1) not in ("end", "global"):
            r["fields"].append({
                "type":    m.group(1),
                "name":    m.group(2),
                "comment": m.group(3),
            })
    return r


# ─────────────────────────────────────────────────────────────────────────────
# SELF CHECK
# ─────────────────────────────────────────────────────────────────────────────

def self_check(results: dict, stats: dict):
    print("\n🔍 SELF-CHECK:")
    all_names = {r["name"] for r in results.values()}
    dw_files  = {r["name"] for r in results.values() if r["object_type"] == "datawindow"}
    for name, r in results.items():
        for dw in r.get("datawindows_used", []):
            if dw not in dw_files:
                w = f'{name} references DataWindow "{dw}" but {dw}.srd not found'
                stats["warnings"].append(w)
                print(f"  ⚠️  {w}")
        for call in r.get("dynamic_sql_calls", []):
            pkg = call["package"]
            if pkg != "stored_procedure" and pkg not in all_names:
                w = f'{name} calls {pkg}.{call["procedure"]} but {pkg}.sru not found'
                stats["warnings"].append(w)
                print(f"  ⚠️  {w}")
        parent = r.get("inherits_from")
        if parent and parent not in PB_BUILTINS and parent not in all_names:
            w = f'{name} inherits from "{parent}" but not found in project'
            stats["warnings"].append(w)
            print(f"  ⚠️  {w}")
        if r["object_type"] == "window" and len(r.get("events", [])) == 0:
            w = f"{name} is a window with ZERO events — possible parsing issue"
            stats["warnings"].append(w)
            print(f"  ⚠️  {w}")
    for name, r in results.items():
        for sp in r.get("stored_procedures", []):
            print(f"  📌 {name} → stored proc: {sp}")
    if not stats["warnings"]:
        print("  ✅ All checks passed")


# ─────────────────────────────────────────────────────────────────────────────
# BUILD OUTPUT
# ─────────────────────────────────────────────────────────────────────────────

def build_output(project_dir: str, results: dict, stats: dict) -> dict:
    # Gap 3: merge parent events into each window
    for r in results.values():
        if r.get('object_type') == 'window' and r.get('inherits_from'):
            r['inherited_events'] = merge_inherited_events(r, results)
    output = {
        "project":   os.path.basename(project_dir),
        "scan_date": datetime.now().isoformat(),
        "stats": {
            **stats,
            "by_type": {
                "windows":      sum(1 for r in results.values() if r["object_type"] == "window"),
                "user_objects": sum(1 for r in results.values() if r["object_type"] == "userobject"),
                "functions":    sum(1 for r in results.values() if r["object_type"] in ("function", "global_function")),
                "structures":   sum(1 for r in results.values() if r["object_type"] == "structure"),
            },
        },
        "files": results,
        "summary": {
            "inheritance":               {},
            "all_dynamic_sql_calls":     [],
            "all_security_events":       [],
            "all_validations_from_code": [],
            "all_datawindow_columns":    {},
            "all_constants":             [],
            "all_stored_procedures":     [],
        },
    }
    s = output["summary"]
    for r in results.values():
        if r.get("inherits_from"):
            s["inheritance"][r["name"]] = r["inherits_from"]
        for c in r.get("dynamic_sql_calls", []):
            s["all_dynamic_sql_calls"].append({"called_by": r["name"], **c})
        for sp in r.get("stored_procedures", []):
            s["all_stored_procedures"].append({"called_by": r["name"], "procedure": sp})
        for ev in r.get("security_events", []):
            s["all_security_events"].append({"logged_by": r["name"], **ev})
        for v in r.get("validations", []):
            s["all_validations_from_code"].append({"window": r["name"], **v})
        for c in r.get("constants", []):
            if "text_" in c["name"] or "help_" in c["name"]:
                s["all_constants"].append({"from": r["name"], **c})
    return output


# ─────────────────────────────────────────────────────────────────────────────
# FILE DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────

def find_pb_files(project_dir: str) -> List[str]:
    exts = {".srw", ".sru", ".srf", ".srs"}
    files = []
    for root, dirs, names in os.walk(project_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__MACOSX"]
        for n in names:
            if Path(n).suffix.lower() in exts:
                files.append(os.path.join(root, n))
    seen, unique = set(), []
    for f in files:
        b = os.path.basename(f)
        if b not in seen:
            seen.add(b)
            unique.append(f)
    return sorted(unique)


# ─────────────────────────────────────────────────────────────────────────────
# EXCEL REPORT GENERATOR
# ─────────────────────────────────────────────────────────────────────────────

class ExcelReportGenerator:
    HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    TITLE_FONT  = Font(name="Calibri", size=14, bold=True)
    BOLD_FONT   = Font(name="Calibri", size=11, bold=True)
    NORMAL_FONT = Font(name="Calibri", size=10)
    THIN_BORDER = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"),  bottom=Side(style="thin")
    )

    def _header_row(self, ws, row: int, headers: List[str]):
        for ci, h in enumerate(headers, 1):
            cell = ws.cell(row=row, column=ci, value=h)
            cell.font = self.HEADER_FONT
            cell.fill = self.HEADER_FILL
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = self.THIN_BORDER

    def _data_rows(self, ws, start: int, end: int, ncols: int):
        for r in range(start, end + 1):
            for c in range(1, ncols + 1):
                cell = ws.cell(row=r, column=c)
                cell.font = self.NORMAL_FONT
                cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
                cell.border = self.THIN_BORDER

    def _col_widths(self, ws, widths: List[int]):
        for idx, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(idx)].width = w

    def generate(self, output: dict, output_path: str):
        wb = Workbook()
        results = output.get("files", {})

        # ── Sheet 1: Master Summary ──────────────────────────────────────────
        ws_sum = wb.active
        ws_sum.title = "Master Summary"
        ws_sum["A1"] = "PowerBuilder Objects — Master Summary"
        ws_sum["A1"].font = self.TITLE_FONT
        ws_sum.merge_cells("A1:J1")
        ws_sum["A2"] = (
            f"Project: {output.get('project','')}  |  "
            f"Scanned: {output.get('scan_date','')}"
        )

        row = 4
        stats = output.get("stats", {})
        by_type = stats.get("by_type", {})
        ws_sum.cell(row=row, column=1, value="Total Files Scanned:").font = self.BOLD_FONT
        ws_sum.cell(row=row, column=2, value=stats.get("files_scanned", 0))
        row += 1
        for label, key in [
            ("Windows (.srw)", "windows"),
            ("User Objects (.sru)", "user_objects"),
            ("Functions (.srf)", "functions"),
            ("Structures (.srs)", "structures"),
        ]:
            ws_sum.cell(row=row, column=1, value=label)
            ws_sum.cell(row=row, column=2, value=by_type.get(key, 0))
            row += 1

        row += 1
        sum_headers = [
            "File Name", "Object Type", "Name", "Category / Inherits",
            "Controls", "Events", "Functions", "Methods",
            "SQL Stmts", "Stored Procs"
        ]
        self._header_row(ws_sum, row, sum_headers)
        row += 1
        data_start = row

        for name, r in results.items():
            otype = r.get("object_type", "")
            ws_sum.cell(row=row, column=1,  value=Path(r.get("file", "")).name)
            ws_sum.cell(row=row, column=2,  value=otype)
            ws_sum.cell(row=row, column=3,  value=r.get("name", ""))
            ws_sum.cell(row=row, column=4,  value=r.get("category") or r.get("inherits_from") or "")
            ws_sum.cell(row=row, column=5,  value=len(r.get("components", [])))
            ws_sum.cell(row=row, column=6,  value=len(r.get("events", [])))
            ws_sum.cell(row=row, column=7,  value=len(r.get("functions", [])))
            ws_sum.cell(row=row, column=8,  value=len(r.get("methods", [])))
            ws_sum.cell(row=row, column=9,  value=len(r.get("sql_statements", [])))
            ws_sum.cell(row=row, column=10, value=len(r.get("stored_procedures", [])))
            row += 1

        if row > data_start:
            self._data_rows(ws_sum, data_start, row - 1, len(sum_headers))
        self._col_widths(ws_sum, [30, 15, 25, 25, 10, 8, 10, 8, 10, 12])
        ws_sum.freeze_panes = f"A{data_start}"

        # ── Sheet 2: Windows ─────────────────────────────────────────────────
        ws_win = wb.create_sheet("Windows")
        ws_win["A1"] = "Window Files Detail"
        ws_win["A1"].font = self.TITLE_FONT
        win_headers = [
            "#", "Window Name", "Inherits From",
            "Width", "Height", "Controls", "Events", "Functions",
            "DataWindows Used", "Lookup References", "Tags"
        ]
        self._header_row(ws_win, 3, win_headers)
        row = 4
        data_start = row
        idx = 1
        for name, r in results.items():
            if r.get("object_type") != "window":
                continue
            tags = ", ".join(
                c.get("tag", "") for c in r.get("components", []) if c.get("tag")
            )
            ws_win.cell(row=row, column=1,  value=idx)
            ws_win.cell(row=row, column=2,  value=r.get("name", ""))
            ws_win.cell(row=row, column=3,  value=r.get("inherits_from") or "")
            ws_win.cell(row=row, column=4,  value=r.get("window_width", 0))
            ws_win.cell(row=row, column=5,  value=r.get("window_height", 0))
            ws_win.cell(row=row, column=6,  value=len(r.get("components", [])))
            ws_win.cell(row=row, column=7,  value=len(r.get("events", [])))
            ws_win.cell(row=row, column=8,  value=len(r.get("functions", [])))
            ws_win.cell(row=row, column=9,  value=", ".join(r.get("datawindows_used", [])))
            ws_win.cell(row=row, column=10, value=", ".join(r.get("lookup_references", [])))
            ws_win.cell(row=row, column=11, value=tags[:200])
            row += 1
            idx += 1
        if row > data_start:
            self._data_rows(ws_win, data_start, row - 1, len(win_headers))
        self._col_widths(ws_win, [5, 30, 25, 8, 8, 8, 8, 10, 35, 35, 40])
        ws_win.freeze_panes = "A4"

        # ── Sheet 3: User Objects ─────────────────────────────────────────────
        ws_uo = wb.create_sheet("User Objects")
        ws_uo["A1"] = "User Object Files Detail"
        ws_uo["A1"].font = self.TITLE_FONT
        uo_headers = [
            "#", "SRU Name", "Category", "Description",
            "Inherits From", "Methods", "Constants",
            "SQL Statements", "Stored Procs", "Line Count"
        ]
        self._header_row(ws_uo, 3, uo_headers)
        row = 4
        data_start = row
        idx = 1
        for name, r in results.items():
            if r.get("object_type") != "userobject":
                continue
            ws_uo.cell(row=row, column=1,  value=idx)
            ws_uo.cell(row=row, column=2,  value=r.get("name", ""))
            ws_uo.cell(row=row, column=3,  value=r.get("category") or "")
            ws_uo.cell(row=row, column=4,  value=r.get("description") or "")
            ws_uo.cell(row=row, column=5,  value=r.get("inherits_from") or "")
            ws_uo.cell(row=row, column=6,  value=len(r.get("methods", [])))
            ws_uo.cell(row=row, column=7,  value=len(r.get("constants", [])))
            ws_uo.cell(row=row, column=8,  value=len(r.get("sql_statements", [])))
            ws_uo.cell(row=row, column=9,  value=len(r.get("stored_procedures", [])))
            ws_uo.cell(row=row, column=10, value=r.get("line_count", 0))
            row += 1
            idx += 1
        if row > data_start:
            self._data_rows(ws_uo, data_start, row - 1, len(uo_headers))
        self._col_widths(ws_uo, [5, 28, 22, 45, 22, 8, 10, 12, 12, 10])
        ws_uo.freeze_panes = "A4"

        # ── Sheet 4: Functions & Structures ──────────────────────────────────
        ws_fn = wb.create_sheet("Functions & Structures")
        ws_fn["A1"] = "Global Functions and Structures"
        ws_fn["A1"].font = self.TITLE_FONT
        fn_headers = ["#", "File Name", "Object Type", "Name", "Return Type", "Purpose", "Parameters / Fields"]
        self._header_row(ws_fn, 3, fn_headers)
        row = 4
        data_start = row
        idx = 1
        for name, r in results.items():
            otype = r.get("object_type", "")
            if otype not in ("function", "global_function", "structure"):
                continue
            if otype == "structure":
                extra = ", ".join(f"{f['type']} {f['name']}" for f in r.get("fields", [])[:10])
            else:
                extra = ", ".join(r.get("parameters", [])[:10])
            ws_fn.cell(row=row, column=1, value=idx)
            ws_fn.cell(row=row, column=2, value=Path(r.get("file", "")).name)
            ws_fn.cell(row=row, column=3, value=otype)
            ws_fn.cell(row=row, column=4, value=r.get("name", ""))
            ws_fn.cell(row=row, column=5, value=r.get("return_type", ""))
            ws_fn.cell(row=row, column=6, value=r.get("purpose") or "")
            ws_fn.cell(row=row, column=7, value=extra)
            row += 1
            idx += 1
        if row > data_start:
            self._data_rows(ws_fn, data_start, row - 1, len(fn_headers))
        self._col_widths(ws_fn, [5, 30, 18, 30, 15, 50, 50])
        ws_fn.freeze_panes = "A4"

        # ── Sheet 5: Events ───────────────────────────────────────────────────
        ws_ev = wb.create_sheet("Events")
        ws_ev["A1"] = "All Window Events"
        ws_ev["A1"].font = self.TITLE_FONT
        ev_headers = [
            "#", "Source File", "Event Name", "Script Length",
            "Has SQL", "Has MessageBox", "Has Validation",
            "SQL Operations", "Function Calls"
        ]
        self._header_row(ws_ev, 3, ev_headers)
        row = 4
        data_start = row
        idx = 1
        for name, r in results.items():
            for ev in r.get("events", []):
                sql_ops = ", ".join(
                    f"{op['operation']}({op['table']})"
                    for op in ev.get("analysis", {}).get("sql_operations", [])
                )
                fn_calls = ", ".join(
                    ev.get("analysis", {}).get("function_calls", [])[:10]
                )
                ws_ev.cell(row=row, column=1, value=idx)
                ws_ev.cell(row=row, column=2, value=name)
                ws_ev.cell(row=row, column=3, value=ev.get("event_name", ""))
                ws_ev.cell(row=row, column=4, value=ev.get("script_length", 0))
                ws_ev.cell(row=row, column=5, value="Y" if ev.get("has_sql") else "N")
                ws_ev.cell(row=row, column=6, value="Y" if ev.get("has_messagebox") else "N")
                ws_ev.cell(row=row, column=7, value="Y" if ev.get("has_validation") else "N")
                ws_ev.cell(row=row, column=8, value=sql_ops)
                ws_ev.cell(row=row, column=9, value=fn_calls[:200])
                row += 1
                idx += 1
        if row > data_start:
            self._data_rows(ws_ev, data_start, row - 1, len(ev_headers))
        self._col_widths(ws_ev, [5, 30, 25, 12, 8, 15, 15, 40, 50])
        ws_ev.freeze_panes = "A4"

        wb.save(output_path)
        print(f"📊 Excel saved: {output_path}  ({os.path.getsize(output_path):,} bytes)")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def generate_pb_objects(
    project_dir: str,
    output_json: str = "pb_objects.json",
    output_xlsx: str = "pb_objects_analysis.xlsx"
) -> List[Dict]:
    print(f"PB Object extractor — scanning {project_dir}")
    files = find_pb_files(project_dir)
    print(f"  Found {len(files)} PB files (.srw/.sru/.srf/.srs)")

    results: Dict[str, Any] = {}
    stats = {"files_scanned": 0, "files_failed": 0, "warnings": []}
    parsers = {
        ".srw": ("window",     parse_window),
        ".sru": ("userobject", parse_user_object),
        ".srf": ("function",   parse_function),
        ".srs": ("structure",  parse_structure),
    }

    for fp in files:
        ext  = Path(fp).suffix.lower()
        name = os.path.basename(fp)
        if ext not in parsers:
            continue
        ftype, parser = parsers[ext]
        try:
            r = parser(fp, read_file(fp))
            if ftype == "window":
                print(
                    f"  📄 {name} (window) → "
                    f"{len(r.get('events', []))} events, "
                    f"{len(r.get('functions', []))} funcs, "
                    f"{len(r.get('components', []))} controls"
                )
            elif ftype == "userobject":
                print(
                    f"  📄 {name} ({r.get('category', 'userobject')}) → "
                    f"{len(r.get('methods', []))} methods, "
                    f"{r.get('line_count', 0)} lines"
                )
            elif ftype == "function":
                print(f"  📄 {name} ({r['object_type']}) → {r.get('purpose', 'no description')}")
            elif ftype == "structure":
                print(f"  📄 {name} (structure) → {len(r.get('fields', []))} fields")
            results[name] = r
            stats["files_scanned"] += 1
        except Exception as e:
            print(f"  ❌ {name} — FAILED: {e}")
            stats["files_failed"] += 1
            stats["warnings"].append(f"Failed to parse {name}: {e}")

    self_check(results, stats)
    output = build_output(project_dir, results, stats)

    print(f"\n{'='*55}")
    print("📊 SUMMARY")
    s = output["stats"]
    print(f"  Files scanned : {s['files_scanned']}")
    print(f"  Files failed  : {s['files_failed']}")
    print(f"  Warnings      : {len(s['warnings'])}")
    bt = s["by_type"]
    print(f"  Windows       : {bt['windows']}")
    print(f"  User objects  : {bt['user_objects']}")
    print(f"  Functions     : {bt['functions']}")
    print(f"  Structures    : {bt['structures']}")

    pb_list = list(results.values())

    # ── Write JSON ────────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(os.path.abspath(output_json)), exist_ok=True)
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(pb_list, f, indent=2, ensure_ascii=False)
    print(f"\n💾 JSON saved: {output_json}  ({os.path.getsize(output_json):,} bytes)")

    full = output_json.replace(".json", "_full.json")
    with open(full, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    print(f"💾 Full output: {full}  ({os.path.getsize(full):,} bytes)")

    # ── Write Excel ───────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(os.path.abspath(output_xlsx)), exist_ok=True)
    ExcelReportGenerator().generate(output, output_xlsx)

    return pb_list


if __name__ == "__main__":
    generate_pb_objects(
        project_dir="/Users/netraballolli/Documents/Discovery/pb_source /GL",
        output_json="pb_objects.json",
        output_xlsx="pb_objects_analysis.xlsx",
    )
