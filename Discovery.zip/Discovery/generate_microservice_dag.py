"""
generate_microservice_dag.py
============================
Generates OpenAPI spec + full .NET microservice code from PB analysis.

Owns:
  - Its own DAGRunner + nodes (OpenAPI, Domain, Application, Infrastructure, API, Solution)
  - Its own prompts

Imports from shared modules:
  - config.py     → all credentials and paths
  - llm_client.py → LLMClient (Anthropic / Copilot)
  - pb_graph.py   → get_context(entity, service)

To run:
  python generate_microservice_dag.py

To add a new generation step (e.g. unit tests):
  1. Create a new class that extends GeneratorNode
  2. Set name and depends_on
  3. Implement run()
  4. Add it in build_runner()
  Nothing else changes.
"""

from __future__ import annotations

import os
import re
import textwrap
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import config
from llm_client import LLMClient
from pb_graph import get_context


# ══════════════════════════════════════════════════════════════════════════════
# SYSTEM PROMPT
# ══════════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT = textwrap.dedent("""
You are an expert .NET architect modernising legacy PowerBuilder applications
to clean .NET 10 microservices following Clean Architecture.

Output rules:
- Complete, compilable, production-quality code — no TODO comments
- Every code block starts with  // <relative-file-path>  as its first line
- No markdown prose between code blocks — code only
- C#: record types, nullable enabled, implicit usings, .NET 10 minimal hosting
- YAML: valid OpenAPI 3.1
""").strip()


# ══════════════════════════════════════════════════════════════════════════════
# PROMPTS
# ══════════════════════════════════════════════════════════════════════════════

def _prompt_openapi(ctx: str, svc: str, entity: str) -> str:
    return textwrap.dedent(f"""
    Generate a complete OpenAPI 3.1 YAML spec for the {svc} microservice.

    - info: title="{svc} API"  version="1.0.0"
    - servers: http://localhost:5000
    - Every DataWindow column → schema property
      (char(N)→string maxLength N, long→integer, decimal→number, datetime→string format date-time)
    - required=Y columns → required array in schema
    - Validation rules from DataWindow → property description
    - Endpoints:
        POST /api/{entity.lower()}s              — create
        GET  /api/{entity.lower()}s/{{id}}       — get by id
      Add extra GET endpoints if the SQL analysis shows additional read patterns.
    - Status codes: 201/400/500 for POST, 200/400/404/500 for GET
    - Include request body schema, response schema, and a generic error schema
    - Add x-pb-source extension on each property with the original PB column name

    PowerBuilder analysis:
    {ctx}

    Output ONLY raw YAML — no markdown fences, no explanation.
    """).strip()


def _prompt_domain(ctx: str, svc: str, entity: str) -> str:
    return textwrap.dedent(f"""
    Generate Domain layer C# for the {svc} microservice.

    Files to produce:
      // {svc}/{svc}.Domain/Entities/{entity}.cs
      // {svc}/{svc}.Domain/Entities/Address.cs
      // {svc}/{svc}.Domain/Entities/Currency.cs
      // {svc}/{svc}.Domain/{svc}.Domain.csproj

    Rules:
    - [Table("db_table")] matching SQL table names from the analysis
    - [Column("col_name")] for every property
    - [Key] [Required] [MaxLength(n)] matching PB constraints
    - [Column(TypeName="decimal(p,s)")] for decimal columns
    - Navigation properties for FK relationships
    - Currency entity: [Table("mc_currency")] — CurrencyId (PK MaxLength 16),
      Description (MaxLength 255 nullable), CurrencyFormat (Required MaxLength 255),
      CheckCurrencyName (Required MaxLength 32), Status (Required MaxLength 1),
      EditDateTime (Required), EditUserId (MaxLength 255 nullable)
    - Vendor entity must have: public Currency Currency {{ get; set; }} navigation property
    - Target: net10.0

    PowerBuilder analysis:
    {ctx}

    Output ONLY C# code blocks, each prefixed  // <filepath>
    """).strip()


def _prompt_application(ctx: str, svc: str, entity: str) -> str:
    return textwrap.dedent(f"""
    Generate Application layer C# for the {svc} microservice.

    Files to produce:
      // {svc}/{svc}.Application/Abstractions/Cqrs/ICommand.cs
      // {svc}/{svc}.Application/Abstractions/Cqrs/IQuery.cs
      // {svc}/{svc}.Application/Abstractions/Cqrs/IDispatcher.cs
      // {svc}/{svc}.Application/Abstractions/I{entity}Repository.cs
      // {svc}/{svc}.Application/Cqrs/Dispatcher.cs
      // {svc}/{svc}.Application/Features/{entity}s/Commands/Create{entity}/Create{entity}Command.cs
      // {svc}/{svc}.Application/Features/{entity}s/Commands/Create{entity}/Create{entity}CommandHandler.cs
      // {svc}/{svc}.Application/Features/{entity}s/Commands/Create{entity}/Create{entity}Result.cs
      // {svc}/{svc}.Application/Features/{entity}s/Queries/Get{entity}ById/Get{entity}ByIdQuery.cs
      // {svc}/{svc}.Application/Features/{entity}s/Queries/Get{entity}ById/Get{entity}ByIdQueryHandler.cs
      // {svc}/{svc}.Application/Features/{entity}s/Queries/Get{entity}ById/{entity}DetailsDto.cs
      // {svc}/{svc}.Application/{svc}.Application.csproj

    Rules:
    - Command: ALL writable fields from DataWindow analysis
    - DetailsDto: ALL readable fields from GET queries
    - CommandHandler: validate required fields + business rules from PB validations
    - Repository interface: every DB operation needed by both handlers
    - Dispatcher: reflection-based handler resolution
    - Include AddressCreateDto in the same file as Create{entity}Command.cs
    - {entity}DetailsDto must include a nested AddressDto record in the same file
    - csproj: net10.0, FluentValidation, Microsoft.Extensions.DependencyInjection.Abstractions

    PowerBuilder analysis:
    {ctx}

    Output ONLY C# code blocks, each prefixed  // <filepath>
    """).strip()


def _prompt_infrastructure(ctx: str, svc: str, entity: str) -> str:
    return textwrap.dedent(f"""
    Generate Infrastructure layer C# for the {svc} microservice.

    Files to produce:
      // {svc}/{svc}.Infrastructure/Persistence/{entity}DbContext.cs
      // {svc}/{svc}.Infrastructure/Repositories/{entity}Repository.cs
      // {svc}/{svc}.Infrastructure/{svc}.Infrastructure.csproj

    Rules:
    - DbContext: DbSet<T> for every entity + related tables from SQL analysis
    - Repository: fully implements I{entity}Repository (no NotImplementedException)
    - EF Core async (AnyAsync, FirstOrDefaultAsync, AddAsync, SaveChangesAsync)
    - .Include() for navigation properties in Get queries
    - FromSqlRaw for stored procedures if found in SQL analysis
    - csproj: net10.0, Microsoft.EntityFrameworkCore.SqlServer

    PowerBuilder analysis:
    {ctx}

    Output ONLY C# code blocks, each prefixed  // <filepath>
    """).strip()


def _prompt_api(ctx: str, svc: str, entity: str) -> str:
    return textwrap.dedent(f"""
    Generate API layer C# for the {svc} microservice.

    Files to produce:
      // {svc}/{svc}.Api/Controllers/{entity}sController.cs
      // {svc}/{svc}.Api/Program.cs
      // {svc}/{svc}.Api/{svc}.Api.csproj
      // {svc}/{svc}.Api/{svc}.Api.http

    Rules:
    - Controller: [ApiController] [Route("api/{entity.lower()}s")] [Produces("application/json")]
    - POST: 201 CreatedAtAction on success, 400 on validation/domain error, 500 on unexpected
    - GET /{{id}}: 200 DetailsDto, 404 not found, 400 bad id
    - Program.cs: minimal host, register DbContext (SqlServer from config),
      all CQRS handlers, repository, AddControllers, AddOpenApi, CORS from config
    - ILogger<TController> for error logging
    - csproj: net10.0, Swashbuckle.AspNetCore, Microsoft.AspNetCore.OpenApi
    - .http file: sample POST and GET requests using @baseUrl = http://localhost:5000

    PowerBuilder analysis:
    {ctx}

    Output ONLY C# code blocks, each prefixed  // <filepath>
    """).strip()


def _prompt_solution(svc: str) -> str:
    return textwrap.dedent(f"""
    Generate the Visual Studio solution file for the {svc} microservice.

    Projects:
      {svc}.Api
      {svc}.Application
      {svc}.Domain
      {svc}.Infrastructure

    First line MUST be:  // {svc}/{svc}.sln
    Output ONLY the raw .sln content — no markdown, no explanation.
    """).strip()


# ══════════════════════════════════════════════════════════════════════════════
# FILE EXTRACTOR
# ══════════════════════════════════════════════════════════════════════════════

def extract_files(raw: str, fallback_ext: str = ".cs") -> Dict[str, str]:
    files: Dict[str, str] = {}

    path_re = re.compile(
        r'^//\s+([\w./\-]+\.(?:cs|csproj|sln|yaml|yml|json|http))\s*$',
        re.MULTILINE,
    )
    splits = list(path_re.finditer(raw))
    if splits:
        for i, match in enumerate(splits):
            fp    = match.group(1).strip()
            start = match.end()
            end   = splits[i + 1].start() if i + 1 < len(splits) else len(raw)
            body  = raw[start:end].strip()
            body  = re.sub(r'^```\w*\n?', '', body)
            body  = re.sub(r'\n?```$', '', body)
            files[fp] = body.strip()
        return files

    for idx, m in enumerate(re.finditer(r'```[\w]*\n([\s\S]*?)```', raw)):
        body  = m.group(1).strip()
        first = body.split('\n')[0]
        pm    = re.match(r'^//\s*([\w./\-]+\.\w+)', first)
        if pm:
            files[pm.group(1)] = '\n'.join(body.split('\n')[1:]).strip()
        else:
            files[f"output_{idx}{fallback_ext}"] = body

    if not files and ('openapi:' in raw or 'info:' in raw):
        files["openapi_spec.yaml"] = raw.strip()

    return files


def write_files(files: Dict[str, str], output_dir: str) -> List[str]:
    written: List[str] = []
    for rel, content in files.items():
        full = Path(output_dir) / rel
        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(content, encoding="utf-8")
        written.append(str(full))
        print(f"      ✅ {rel}  ({len(content):,} chars)")
    return written


# ══════════════════════════════════════════════════════════════════════════════
# DAG — base node + runner
# ══════════════════════════════════════════════════════════════════════════════

class GeneratorNode(ABC):
    name:       str
    depends_on: List[str] = []

    @abstractmethod
    def run(
        self,
        upstream:      Dict[str, Any],
        context:       str,
        llm:           LLMClient,
        service:       str,
        entity:        str,
        output_dir:    str,
        skip_existing: bool,
    ) -> Dict[str, Any]:
        ...


class DAGRunner:
    def __init__(self):
        self._nodes: Dict[str, GeneratorNode] = {}

    def register(self, node: GeneratorNode) -> "DAGRunner":
        self._nodes[node.name] = node
        return self

    def _topo_sort(self, only: Optional[Set[str]] = None) -> List[str]:
        if only:
            needed: Set[str] = set()
            queue = list(only)
            while queue:
                n = queue.pop()
                if n in needed:
                    continue
                if n not in self._nodes:
                    raise ValueError(f"Unknown node '{n}'. Available: {list(self._nodes)}")
                needed.add(n)
                queue.extend(self._nodes[n].depends_on)
        else:
            needed = set(self._nodes)

        in_degree: Dict[str, int] = {n: 0 for n in needed}
        adj:       Dict[str, List[str]] = {n: [] for n in needed}
        for n in needed:
            for dep in self._nodes[n].depends_on:
                if dep in needed:
                    adj[dep].append(n)
                    in_degree[n] += 1

        queue2 = sorted(n for n in needed if in_degree[n] == 0)
        order:  List[str] = []
        while queue2:
            node = queue2.pop(0)
            order.append(node)
            for succ in adj[node]:
                in_degree[succ] -= 1
                if in_degree[succ] == 0:
                    queue2.append(succ)
            queue2.sort()

        if len(order) != len(needed):
            raise ValueError(f"Cycle detected in DAG: {needed - set(order)}")
        return order

    def run(
        self,
        context:       str,
        llm:           LLMClient,
        service:       str,
        entity:        str,
        output_dir:    str,
        skip_existing: bool = False,
        only:          Optional[Set[str]] = None,
    ) -> Dict[str, Any]:
        order    = self._topo_sort(only)
        results: Dict[str, Any] = {}
        all_files: List[str]    = []

        print(f"\n  DAG order: {' → '.join(order)}\n")

        for node_name in order:
            node     = self._nodes[node_name]
            upstream = {dep: results[dep] for dep in node.depends_on if dep in results}
            result   = node.run(
                upstream, context, llm, service, entity, output_dir, skip_existing
            )
            results[node_name] = result
            if isinstance(result.get("files"), list):
                all_files.extend(result["files"])

        return {"node_results": results, "all_files": all_files}


# ══════════════════════════════════════════════════════════════════════════════
# NODES — one per layer
# ══════════════════════════════════════════════════════════════════════════════

class OpenApiNode(GeneratorNode):
    name       = "openapi"
    depends_on = []

    def run(self, upstream, context, llm, service, entity, output_dir, skip_existing):
        target = Path(output_dir) / "openapi_spec.yaml"
        if skip_existing and target.exists():
            print("    ⏭️  skipping openapi")
            return {"path": str(target)}
        print("  📄 Generating OpenAPI spec...")
        raw = llm.generate(SYSTEM_PROMPT, _prompt_openapi(context, service, entity), "openapi")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(raw, encoding="utf-8")
        print(f"      ✅ openapi_spec.yaml  ({len(raw):,} chars)")
        return {"path": str(target)}


class DomainNode(GeneratorNode):
    name       = "domain"
    depends_on = []

    def run(self, upstream, context, llm, service, entity, output_dir, skip_existing):
        print("  🏗️  Generating Domain layer...")
        raw   = llm.generate(SYSTEM_PROMPT, _prompt_domain(context, service, entity), "domain")
        files = extract_files(raw)
        if skip_existing:
            files = {k: v for k, v in files.items() if not (Path(output_dir) / k).exists()}
        return {"files": write_files(files, output_dir)}


class ApplicationNode(GeneratorNode):
    name       = "application"
    depends_on = ["domain"]

    def run(self, upstream, context, llm, service, entity, output_dir, skip_existing):
        print("  ⚙️  Generating Application layer...")
        raw   = llm.generate(SYSTEM_PROMPT, _prompt_application(context, service, entity), "application")
        files = extract_files(raw)
        if skip_existing:
            files = {k: v for k, v in files.items() if not (Path(output_dir) / k).exists()}
        return {"files": write_files(files, output_dir)}


class InfrastructureNode(GeneratorNode):
    name       = "infrastructure"
    depends_on = ["domain", "application"]

    def run(self, upstream, context, llm, service, entity, output_dir, skip_existing):
        print("  🗄️  Generating Infrastructure layer...")
        raw   = llm.generate(SYSTEM_PROMPT, _prompt_infrastructure(context, service, entity), "infrastructure")
        files = extract_files(raw)
        if skip_existing:
            files = {k: v for k, v in files.items() if not (Path(output_dir) / k).exists()}
        return {"files": write_files(files, output_dir)}


class ApiNode(GeneratorNode):
    name       = "api"
    depends_on = ["domain", "application", "infrastructure"]

    def run(self, upstream, context, llm, service, entity, output_dir, skip_existing):
        print("  🌐 Generating API layer...")
        raw   = llm.generate(SYSTEM_PROMPT, _prompt_api(context, service, entity), "api")
        files = extract_files(raw)
        if skip_existing:
            files = {k: v for k, v in files.items() if not (Path(output_dir) / k).exists()}
        return {"files": write_files(files, output_dir)}


class SolutionNode(GeneratorNode):
    name       = "solution"
    depends_on = ["domain", "application", "infrastructure", "api"]

    def run(self, upstream, context, llm, service, entity, output_dir, skip_existing):
        print("  📦 Generating solution file...")
        raw   = llm.generate(SYSTEM_PROMPT, _prompt_solution(service), "solution")
        files = extract_files(raw, fallback_ext=".sln")
        if not files:
            sln_path = Path(output_dir) / service / f"{service}.sln"
            sln_path.parent.mkdir(parents=True, exist_ok=True)
            clean = re.sub(r'^//[^\n]+\n', '', raw.strip())
            sln_path.write_text(clean, encoding="utf-8")
            print(f"      ✅ {service}/{service}.sln")
            return {"files": [str(sln_path)]}
        return {"files": write_files(files, output_dir)}


def build_runner() -> DAGRunner:
    """Register all nodes. To add a new step — add it here only."""
    return (
        DAGRunner()
        .register(OpenApiNode())
        .register(DomainNode())
        .register(ApplicationNode())
        .register(InfrastructureNode())
        .register(ApiNode())
        .register(SolutionNode())
    )


# ══════════════════════════════════════════════════════════════════════════════
# PIPELINE
# ══════════════════════════════════════════════════════════════════════════════

def run_pipeline(
    service_name:   str,
    entity_name:    str,
    output_dir:     str,
    skip_existing:  bool = False,
    only_nodes:     Optional[Set[str]] = None,
) -> Dict[str, Any]:

    print(f"\n{'═'*60}")
    print(f"  Microservice generator")
    print(f"  Service : {service_name}")
    print(f"  Entity  : {entity_name}")
    print(f"  Output  : {output_dir}")
    print(f"  LLM     : {'Anthropic' if config.USE_DIRECT_ANTHROPIC else 'GitHub Copilot'}")
    print(f"{'═'*60}\n")

    # 1. Get context from Neo4j
    print("📖 Building context from Neo4j...")
    context = get_context(entity_name, service_name)
    print(f"   Context: {len(context):,} chars")

    # Save context for debugging
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    ctx_path = Path(output_dir) / "_analysis_context.txt"
    ctx_path.write_text(context, encoding="utf-8")
    print(f"   Saved : {ctx_path}\n")

    # 2. Run DAG
    llm    = LLMClient()
    runner = build_runner()
    result = runner.run(
        context       = context,
        llm           = llm,
        service       = service_name,
        entity        = entity_name,
        output_dir    = output_dir,
        skip_existing = skip_existing,
        only          = only_nodes,
    )

    total = len(result["all_files"])
    print(f"\n{'═'*60}")
    print(f"✅ Done — {total} files written → {Path(output_dir).resolve()}")
    print(f"{'═'*60}\n")
    return result


# ══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT — edit below, then run:  python generate_microservice_dag.py
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":

    # ── Service details ───────────────────────────────────────────────────────
    SERVICE_NAME = "ApVendor"
    ENTITY_NAME  = "Vendor"

    # ── Output folder ─────────────────────────────────────────────────────────
    OUTPUT_DIR = config.OUTPUT_DIR     # from config.py, or override here

    # ── Optional ──────────────────────────────────────────────────────────────
    SKIP_EXISTING = False   # True = skip nodes whose files already exist
    ONLY_NODES    = None    # None = run all  |  e.g. {"openapi", "domain"}

    run_pipeline(
        service_name  = SERVICE_NAME,
        entity_name   = ENTITY_NAME,
        output_dir    = OUTPUT_DIR,
        skip_existing = SKIP_EXISTING,
        only_nodes    = ONLY_NODES,
    )
