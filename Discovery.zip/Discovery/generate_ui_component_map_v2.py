"""
generate_ui_component_map_v2.py
================================
Reads  datawindows.json  →  produces  ui_component_map.json

WHAT THIS PRODUCES (architect-spec)
-------------------------------------
For every DataWindow, a language-independent UI blueprint:

  1. design_system_imports  — DISTINCT set of components the UI dev needs to import
                              e.g. ["TextInput","Select","DatePicker","Tabs","SearchBar"]

  2. tabs[]                 — one entry per logical tab (from vtab sections in source)
       └── groups[]         — LLM-named logical groups within the tab
             └── fields[]   — lean field descriptors (label, component, required,
                              readonly, options) — NO db internals, NO x/y coords

WHAT IS INTENTIONALLY EXCLUDED
--------------------------------
- DB column mappings / BFF DTO codegen details
- x / y / width / height coordinates
- Raw SQL / sql_query internals
- div-chunking (renderer concern, not a blueprint concern)

LLM USAGE (WatsonX)
--------------------
LLM is called ONCE per tab per DataWindow to intelligently name and group fields.
Pure Python handles everything else (component detection, tab structure, imports).

CONFIGURATION  — edit the variables inside main() at the bottom of this file
------------------------------------------------------------------------------
  INPUT_PATH     — path to your datawindows.json
  OUTPUT_PATH    — where to write ui_component_map.json
  API_KEY        — IBM Cloud API key  (from datawindow_metrics_v8 pattern)
  PROJECT_ID     — WatsonX project ID
  ENDPOINT_URL   — WatsonX generation endpoint
  MODEL_ID       — model to use (e.g. ibm/granite-13b-instruct-v2)
  USE_LLM        — set False to skip LLM and use Python-only grouping

Run: python generate_ui_component_map_v2.py
"""

from __future__ import annotations

import json
import re
import traceback
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import requests


# ══════════════════════════════════════════════════════════════════════════════
# WATSONX CLIENT  — mirrors pattern from datawindow_metrics_v8.py exactly
# ══════════════════════════════════════════════════════════════════════════════

class WatsonxClient:
    """Client for IBM watsonx.ai API"""

    def __init__(self, api_key: str, project_id: str, endpoint_url: str, model_id: str):
        self.api_key      = api_key
        self.project_id   = project_id
        self.endpoint_url = endpoint_url
        self.model_id     = model_id
        self.access_token = None
        self._get_access_token()

    def _get_access_token(self):
        """Get Bearer token from IBM Cloud IAM"""
        token_url = "https://iam.cloud.ibm.com/identity/token"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept":       "application/json",
        }
        data = {
            "apikey":     self.api_key,
            "grant_type": "urn:ibm:params:oauth:grant-type:apikey",
        }
        try:
            print("🔑 Obtaining access token from IBM Cloud IAM...")
            response = requests.post(token_url, headers=headers, data=data, timeout=30)
            response.raise_for_status()
            result = response.json()
            self.access_token = result.get("access_token")
            if not self.access_token:
                raise ValueError("No access_token in IAM response")
            print("✅ Access token obtained successfully\n")
        except requests.exceptions.RequestException as e:
            print(f"⚠️  Warning: Failed to get access token: {e}")
            print("   Script will continue with Python-only grouping.\n")
            self.access_token = None

    def generate(self, prompt: str, max_tokens: int = 1200) -> Optional[str]:
        """Generate text using watsonx.ai. Returns generated text or None on failure."""
        if not self.access_token:
            return None

        headers = {
            "Accept":        "application/json",
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {self.access_token}",
        }
        body = {
            "input": prompt,
            "parameters": {
                "decoding_method":    "greedy",
                "max_new_tokens":     max_tokens,
                "min_new_tokens":     10,
                "repetition_penalty": 1.1,
            },
            "model_id":   self.model_id,
            "project_id": self.project_id,
        }
        try:
            response = requests.post(self.endpoint_url, headers=headers, json=body, timeout=120)
            response.raise_for_status()
            data = response.json()
            return data["results"][0]["generated_text"].strip()
        except Exception as e:
            print(f"⚠️  LLM API call failed: {e}")
            return None


# ══════════════════════════════════════════════════════════════════════════════
# COMPONENT TYPE DETECTOR  — pure Python, no LLM needed
# ══════════════════════════════════════════════════════════════════════════════

def _detect_component(col: Dict) -> str:
    et   = (col.get("edit_type")  or "").upper()
    dt   = (col.get("data_type")  or "").lower()
    ft   = (col.get("field_type") or "").upper()
    name = (col.get("name")       or "").lower()
    prot = col.get("protected", "N")

    if et in ("DDDW", "DDLB"):                      return "Select"
    if et == "CHECKBOX" or ft == "CHECKBOX":         return "Checkbox"
    if ft == "RADIOBUTTON":                          return "RadioGroup"
    if et == "EDITMASK":                             return "MaskedInput"
    if prot == "Y":                                  return "ReadOnlyField"
    if "date" in dt:                                 return "DatePicker"
    if "decimal" in dt or "numeric" in dt:
        if any(x in name for x in ("amount", "balance", "percent", "rate", "price")):
            return "CurrencyInput"
        return "NumberInput"
    if "long" in dt or "int" in dt:                  return "NumberInput"
    if "char(255)" in dt or "text" in dt:            return "Textarea"
    if re.match(r"char\(1\)$", dt):                  return "Select"
    if "email" in name:                              return "EmailInput"
    if "web" in name or "url" in name:               return "UrlInput"
    if "phone" in name or "telephone" in name or "fax" in name: return "PhoneInput"
    return "TextInput"


def _has_lookup_search(col: Dict, lookup_controls: List[Dict]) -> bool:
    """True if this field has a LookupSearch control linked to it."""
    name = col.get("name", "")
    return any(
        lc.get("linked_column") == name and lc.get("kind") == "LookupSearch"
        for lc in lookup_controls
    )


# ══════════════════════════════════════════════════════════════════════════════
# LABEL LOOKUP  — match Text label controls to Column controls by proximity
# ══════════════════════════════════════════════════════════════════════════════

def _build_label_lookup(all_controls: List[Dict]) -> Dict[str, str]:
    label_map:  Dict[str, str] = {}
    text_cols   = [c for c in all_controls if c.get("field_type") == "Text"   and c.get("column_name")]
    column_cols = [c for c in all_controls if c.get("field_type") == "Column"]

    # Direct column_name on the column control itself
    for col in column_cols:
        if col.get("column_name"):
            label_map[col["name"]] = col["column_name"]

    # Proximity matching for any remaining
    for col in column_cols:
        if col["name"] in label_map:
            continue
        cx, cy = col.get("x", 0), col.get("y", 0)
        best_text, best_dist = None, float("inf")
        for txt in text_cols:
            tx, ty = txt.get("x", 0), txt.get("y", 0)
            if abs(tx - cx) <= 20 and -10 <= (cy - ty) <= 60:
                dist = abs(tx - cx) + abs(ty - cy)
                if dist < best_dist:
                    best_dist, best_text = dist, txt["column_name"]
        if best_text:
            label_map[col["name"]] = best_text

    return label_map


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _humanise(s: str) -> str:
    return " ".join(w.capitalize() for w in (s or "").replace("_", " ").split())


def _parse_options(raw: str) -> List[Dict[str, str]]:
    if not raw:
        return []
    opts = []
    for part in re.split(r'[|\n\\n]', raw):
        part = part.strip()
        if not part:
            continue
        if "/" in part:
            val, _, label = part.partition("/")
            opts.append({"value": val.strip(), "label": label.strip()})
        else:
            opts.append({"value": part, "label": part})
    return opts


# ══════════════════════════════════════════════════════════════════════════════
# LEAN FIELD BUILDER  — only what a UI developer needs
# ══════════════════════════════════════════════════════════════════════════════

def _build_lean_field(col: Dict, label_map: Dict[str, str], lookup_controls: List[Dict]) -> Dict:
    name      = col.get("name", "")
    label     = label_map.get(name) or col.get("column_name") or _humanise(name)
    component = _detect_component(col)

    field: Dict = {
        "name":      name,
        "label":     label,
        "component": component,
        "required":  col.get("required", "N") == "Y",
        "readonly":  col.get("protected", "N") == "Y",
    }

    # Dropdown / radio options
    if component in ("Select", "RadioGroup", "Checkbox"):
        opts = _parse_options(col.get("edit_values", ""))
        if opts:
            field["options"] = opts
        dddw = col.get("dddw_dataobject") or None
        if dddw:
            field["options_source"] = dddw

    # Search/lookup indicator — tells UI dev a SearchBar is needed
    if _has_lookup_search(col, lookup_controls):
        field["has_lookup_search"] = True

    # Date format hint
    if component == "DatePicker":
        field["format"] = "MM/DD/YYYY"

    # Max length hint (useful for TextInput sizing)
    dt = col.get("data_type", "")
    m  = re.search(r'char\s*\((\d+)\)', dt or "", re.I)
    if m:
        field["max_length"] = int(m.group(1))

    return field


# ══════════════════════════════════════════════════════════════════════════════
# TAB → FIELD MAP  — derived from vtab sections already in the JSON
# ══════════════════════════════════════════════════════════════════════════════

def _build_tab_field_map(dw: Dict, label_map: Dict[str, str]) -> Dict[str, List[Dict]]:
    """
    Returns { tab_label: [lean_fields] } using vtab section data in the JSON.
    If no sections exist, all fields go under a single "Main" tab.
    """
    lookup_controls = dw.get("lookup_controls", [])
    sections        = dw.get("sections", [])
    table_columns   = {c["name"]: c for c in dw.get("table_columns", [])}

    if sections:
        tab_map: Dict[str, List[Dict]] = {}
        for sec in sections:
            tab_label = sec.get("label") or _humanise(sec.get("name", "Main"))
            for col_name in sec.get("columns", []):
                col = table_columns.get(col_name)
                if col:
                    tab_map.setdefault(tab_label, []).append(
                        _build_lean_field(col, label_map, lookup_controls)
                    )

        # Fields not assigned to any section → "Main"
        assigned = {fn for sec in sections for fn in sec.get("columns", [])}
        unassigned = [
            _build_lean_field(col, label_map, lookup_controls)
            for col in dw.get("table_columns", [])
            if col["name"] not in assigned
        ]
        if unassigned:
            tab_map["Main"] = unassigned + tab_map.get("Main", [])
        return tab_map

    # No sections — single tab
    all_fields = [
        _build_lean_field(col, label_map, lookup_controls)
        for col in dw.get("table_columns", [])
    ]
    return {"Main": all_fields} if all_fields else {}


# ══════════════════════════════════════════════════════════════════════════════
# LLM GROUPING  — one call per tab, asks WatsonX to name and group fields
# ══════════════════════════════════════════════════════════════════════════════

def _build_grouping_prompt(dw_name: str, tab_label: str, fields: List[Dict]) -> str:
    field_list = "\n".join(
        f'  - name="{f["name"]}" label="{f["label"]}" component="{f["component"]}"'
        for f in fields
    )
    return f"""You are a UI architect. Given the fields below from the "{tab_label}" tab of a DataWindow named "{dw_name}", group them into logical UI sections.

Rules:
- Return ONLY a valid JSON array. No explanation, no markdown, no code fences.
- Each element: {{"group_label": "...", "field_names": ["field1", "field2", ...]}}
- Every field_name must appear in exactly one group.
- Group names must be short (2-4 words), human-readable, title-case.
- Group related fields together (e.g. address fields, banking fields, audit fields).
- Do not create groups with only 1 field unless unavoidable.

Fields:
{field_list}

JSON array:"""


def _parse_llm_groups(raw: str, all_field_names: Set[str]) -> Optional[List[Dict]]:
    """Parse and validate LLM JSON output. Returns list of groups or None on failure."""
    if not raw:
        return None

    # Strip markdown fences if model adds them
    text  = re.sub(r"```(?:json)?", "", raw).strip()
    start = text.find("[")
    end   = text.rfind("]")
    if start == -1 or end == -1:
        return None

    try:
        groups = json.loads(text[start: end + 1])
    except json.JSONDecodeError:
        return None

    if not isinstance(groups, list):
        return None

    valid: List[Dict]     = []
    seen_fields: Set[str] = set()

    for g in groups:
        if not isinstance(g, dict):
            continue
        label  = g.get("group_label") or g.get("label") or g.get("name") or "General"
        fnames = [f for f in (g.get("field_names") or [])
                  if f in all_field_names and f not in seen_fields]
        if fnames:
            seen_fields.update(fnames)
            valid.append({"group_label": str(label), "field_names": fnames})

    # Catch any fields the LLM missed
    missed = [f for f in all_field_names if f not in seen_fields]
    if missed:
        valid.append({"group_label": "Other", "field_names": missed})

    return valid if valid else None


# ══════════════════════════════════════════════════════════════════════════════
# PURE-PYTHON FALLBACK GROUPER
# Used when USE_LLM = False or when LLM call fails
# ══════════════════════════════════════════════════════════════════════════════

_PY_GROUP_PATTERNS: List[Tuple] = [
    (re.compile(r'^(bank_|ach_|routing|account_num|bank_account)',         re.I), "Banking & ACH"),
    (re.compile(r'^(tax_|tin_|1099|irs_|backup_with|tax_id)',              re.I), "Tax Information"),
    (re.compile(r'^(purchasing_address|pay_addr|paym_addr|payment_addr)',  re.I), "Purchasing Address"),
    (re.compile(r'^(shipping_|ship_addr)',                                  re.I), "Shipping Address"),
    (re.compile(r'^(street|city|state|postal|country|zip|address|addr)',   re.I), "Address"),
    (re.compile(r'^(payment_term|trade_discount|min_order|min_pay|'
                 r'max_purch|credit_limit|max_write)',                      re.I), "Financial Terms"),
    (re.compile(r'^(current_bal|highest_bal|last_pay|last_purch)',         re.I), "Account Balances"),
    (re.compile(r'^(edi_|electronic_|elec_notif|electronic_payment)',      re.I), "Electronic Settings"),
    (re.compile(r'^(vendor_class|payment_priority|free_on_board|reminder)',re.I), "Vendor Classification"),
    (re.compile(r'^(added_date|edit_date|added_dt|edit_dt|edit_user|'
                 r'added_user)',                                             re.I), "Audit Information"),
    (re.compile(r'^(vendor_id|name|status|vendor_account|exp_user)',       re.I), "Vendor Identity"),
]


def _python_group_fields(fields: List[Dict]) -> List[Dict]:
    """Assign fields to groups using regex patterns (fallback when LLM unavailable)."""
    buckets: Dict[str, List[str]] = {}
    for f in fields:
        matched = False
        for pattern, group_label in _PY_GROUP_PATTERNS:
            if pattern.match(f["name"]):
                buckets.setdefault(group_label, []).append(f["name"])
                matched = True
                break
        if not matched:
            buckets.setdefault("General Information", []).append(f["name"])
    return [{"group_label": lbl, "field_names": names} for lbl, names in buckets.items()]


# ══════════════════════════════════════════════════════════════════════════════
# GROUP BUILDER  — LLM with Python fallback
# ══════════════════════════════════════════════════════════════════════════════

def _build_groups(
    dw_name:   str,
    tab_label: str,
    fields:    List[Dict],
    client:    Optional[WatsonxClient],
) -> List[Dict]:
    """Returns list of { group_label, fields[] } for one tab."""
    field_by_name = {f["name"]: f for f in fields}
    use_llm       = client is not None and client.access_token is not None

    if use_llm:
        try:
            prompt     = _build_grouping_prompt(dw_name, tab_label, fields)
            raw        = client.generate(prompt, max_tokens=1200)
            llm_groups = _parse_llm_groups(raw, set(field_by_name.keys()))
            if llm_groups:
                print(f"      🤖 LLM grouped {len(fields)} fields → {len(llm_groups)} groups")
                return [
                    {
                        "group_label": g["group_label"],
                        "fields": [field_by_name[n] for n in g["field_names"] if n in field_by_name],
                    }
                    for g in llm_groups
                ]
            else:
                print("      ⚠️  LLM returned unparseable response, falling back to Python grouping")
        except Exception as e:
            print(f"      ⚠️  LLM error ({e}), falling back to Python grouping")

    # Python fallback
    py_groups = _python_group_fields(fields)
    return [
        {
            "group_label": g["group_label"],
            "fields": [field_by_name[n] for n in g["field_names"] if n in field_by_name],
        }
        for g in py_groups
        if any(n in field_by_name for n in g["field_names"])
    ]


# ══════════════════════════════════════════════════════════════════════════════
# DESIGN SYSTEM IMPORTS  — distinct ordered component set across all tabs
# ══════════════════════════════════════════════════════════════════════════════

_IMPORT_ORDER = [
    "Tabs", "TextInput", "Select", "DatePicker", "NumberInput", "CurrencyInput",
    "MaskedInput", "Textarea", "Checkbox", "RadioGroup", "EmailInput", "PhoneInput",
    "UrlInput", "ReadOnlyField", "SearchBar", "DataGrid",
]


def _collect_imports(tabs: List[Dict], has_tabs: bool, is_grid: bool) -> List[str]:
    imports: Set[str] = set()
    if has_tabs:
        imports.add("Tabs")
    if is_grid:
        imports.add("DataGrid")
    for tab in tabs:
        for group in tab.get("groups", []):
            for field in group.get("fields", []):
                imports.add(field["component"])
                if field.get("has_lookup_search"):
                    imports.add("SearchBar")
    ordered = [c for c in _IMPORT_ORDER if c in imports]
    extra   = sorted(imports - set(_IMPORT_ORDER))
    return ordered + extra


# ══════════════════════════════════════════════════════════════════════════════
# GRID DESCRIPTOR  — for Grid-style DataWindows
# ══════════════════════════════════════════════════════════════════════════════

def _build_grid_descriptor(dw: Dict, label_map: Dict[str, str]) -> Optional[Dict]:
    ps = (dw.get("presentation_style") or dw.get("type", "")).lower()
    if ps != "grid":
        return None
    cols = []
    for col in dw.get("table_columns", []):
        name  = col.get("name", "")
        label = label_map.get(name) or col.get("column_name") or _humanise(name)
        cols.append({
            "name":      name,
            "label":     label,
            "component": _detect_component(col),
            "sortable":  True,
        })
    return {"columns": cols}


# ══════════════════════════════════════════════════════════════════════════════
# NAVIGATION ACTIONS
# ══════════════════════════════════════════════════════════════════════════════

def _build_nav_actions(dw: Dict) -> List[Dict]:
    return [
        {
            "name":   nb.get("name", ""),
            "label":  nb.get("label", ""),
            "kind":   nb.get("kind", ""),
            "target": nb.get("target_window", ""),
        }
        for nb in dw.get("navigation_buttons", [])
    ]


# ══════════════════════════════════════════════════════════════════════════════
# MAIN PROCESSOR  — one DataWindow → UI blueprint
# ══════════════════════════════════════════════════════════════════════════════

def process_datawindow(dw: Dict, client: Optional[WatsonxClient]) -> Dict:
    dw_name = dw.get("name", "unknown")
    ps      = (dw.get("presentation_style") or dw.get("type", "")).lower()
    print(f"\n  Processing: {dw_name}  [{ps}]")

    all_controls = dw.get("controls", []) + dw.get("table_columns", [])
    label_map    = _build_label_lookup(all_controls)

    # Grid DataWindows → simple DataGrid blueprint, no tabs
    grid_desc = _build_grid_descriptor(dw, label_map)
    if grid_desc:
        print(f"    → Grid: {len(grid_desc['columns'])} columns")
        return {
            "screen":                dw_name,
            "presentation_style":    ps,
            "source_file":           dw.get("file", ""),
            "retrieval_args":        dw.get("arguments", []),
            "design_system_imports": ["DataGrid"],
            "layout_type":           "grid",
            "grid":                  grid_desc,
            "navigation_actions":    _build_nav_actions(dw),
        }

    # Freeform / Tabbed DataWindows
    tab_field_map = _build_tab_field_map(dw, label_map)
    has_tabs      = len(tab_field_map) > 1

    tabs_out = []
    for tab_label, fields in tab_field_map.items():
        if not fields:
            continue
        print(f"    Tab '{tab_label}': {len(fields)} fields")
        groups = _build_groups(dw_name, tab_label, fields, client)
        tabs_out.append({"tab": tab_label, "groups": groups})

    imports = _collect_imports(tabs_out, has_tabs, False)

    total_fields = sum(len(g["fields"]) for tab in tabs_out for g in tab["groups"])
    total_groups = sum(len(tab["groups"]) for tab in tabs_out)

    print(f"    → {len(tabs_out)} tabs, {total_groups} groups, {total_fields} fields")
    print(f"    → imports: {imports}")

    return {
        "screen":                dw_name,
        "presentation_style":    ps,
        "source_file":           dw.get("file", ""),
        "retrieval_args":        dw.get("arguments", []),
        "design_system_imports": imports,
        "layout_type":           "tabbed" if has_tabs else "single-page",
        "tabs":                  tabs_out,
        "navigation_actions":    _build_nav_actions(dw),
        "_meta": {
            "tab_count":   len(tabs_out),
            "group_count": total_groups,
            "field_count": total_fields,
        },
    }


# ══════════════════════════════════════════════════════════════════════════════
# MAIN  — update configuration variables here, no command-line arguments needed
# ══════════════════════════════════════════════════════════════════════════════

def main():

    # ╔══════════════════════════════════════════════════════════════════════╗
    # ║                  CONFIGURATION — UPDATE THESE VALUES                ║
    # ╠══════════════════════════════════════════════════════════════════════╣

    INPUT_PATH   = "/Users/netraballolli/Documents/Discovery/datawindows.json"
    OUTPUT_PATH  = "/Users/netraballolli/Documents/Discovery/ui_component_map.json"

    # IBM watsonx.ai credentials
    API_KEY      = "AA0hq9sWcZ8BX2TsmGRZc2uNWDnDR0oiQIVesAHsPdxC"
    PROJECT_ID   = "179320b9-8251-46d8-89f1-6330f7bdab38"
    ENDPOINT_URL = "https://us-south.ml.cloud.ibm.com/ml/v1/text/generation?version=2023-05-29"
    MODEL_ID     = "ibm/granite-13b-instruct-v2"

    # Set to False to skip LLM and use Python-only grouping (faster, offline)
    USE_LLM      = True

    # ╚══════════════════════════════════════════════════════════════════════╝

    print("=" * 60)
    print("UI Component Map Generator v2")
    print(f"  Input  : {INPUT_PATH}")
    print(f"  Output : {OUTPUT_PATH}")
    print(f"  LLM    : {'WatsonX (' + MODEL_ID + ')' if USE_LLM else 'disabled (Python only)'}")
    print("=" * 60)

    if not Path(INPUT_PATH).exists():
        print(f"\n⚠️  Error: Input file not found: {INPUT_PATH}")
        return

    with open(INPUT_PATH, encoding="utf-8") as f:
        datawindows = json.load(f)

    print(f"  Found {len(datawindows)} DataWindow(s)")

    # Initialise WatsonX client — mirrors WatsonxClient pattern from datawindow_metrics_v8.py
    # If token fetch fails, client.access_token stays None and Python grouping is used
    client: Optional[WatsonxClient] = None
    if USE_LLM:
        try:
            client = WatsonxClient(
                api_key      = API_KEY,
                project_id   = PROJECT_ID,
                endpoint_url = ENDPOINT_URL,
                model_id     = MODEL_ID,
            )
        except Exception as e:
            print(f"⚠️  Warning: Could not initialise WatsonX client: {e}")
            print("   Continuing with Python-only grouping.\n")

    # Process each DataWindow
    results = []
    for dw in datawindows:
        try:
            blueprint = process_datawindow(dw, client)
            results.append(blueprint)
        except Exception as e:
            print(f"\n  ❌ FAILED: {dw.get('name', '?')} — {e}")
            traceback.print_exc()

    # Write output
    out_path = Path(OUTPUT_PATH)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    size = out_path.stat().st_size
    print(f"\n✅ Done — {len(results)} screen(s) written to {OUTPUT_PATH}  ({size:,} bytes)")


if __name__ == "__main__":
    main()
