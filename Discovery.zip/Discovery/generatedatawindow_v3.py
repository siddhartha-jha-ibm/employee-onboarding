"""
generatedatawindow.py  (v8-enhanced)
=====================================
Produces datawindows.json + datawindows_analysis.xlsx from a PowerBuilder
project directory.

Incorporates all fixes from datawindow_metrics_v8.py:
  - Full ColumnInfo dataclass with Protected/Required/Tag/EditType/PopupScreens
  - Proper protect value interpreter  (0→N, 1→Y, 0~tIf(...)→expression)
  - Proper required value interpreter (yes/1→Y, no/0→N)
  - Visual column band/tabsequence/edit-style merging
  - Text, Compute, Button, Bitmap, Rectangle, Line, GroupBox, RadioButton extraction
  - RadioButton label (text attribute) captured as column_name
  - DDDW cross-DataWindow reference captured as dddw_dataobject field
    (e.g. dddw.name = d_im_site_purchasing_dddw stored on the column)
  - Paren-balanced compute expression extractor — captures multi-term
    expressions like credit_limit_amount - current_balance in full
  - Popup/lookup pattern detection (sjmp_, look_)
  - Filters and Sorts extraction
  - Lookup count (DDDW + sjmp_/look_ controls)
  - Excel intermediate output: per-DW sheets + Master Summary sheet

Output files:
  datawindows.json           — structured JSON consumed by agents
  datawindows_analysis.xlsx  — rich Excel workbook for human review
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field, asdict
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ─────────────────────────────────────────────────────────────────────────────
# DATA CLASSES
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ColumnInfo:
    name: str
    column_name: str = ""      # display label / text value
    field_type: str = ""       # Column, Text, Compute, Button, Image, Rectangle, Line, GroupBox
    data_type: str = ""        # char(16), long, decimal, datetime …
    db_name: str = ""
    visible: str = "Y"
    protected: str = "N"       # N / Y / expression
    required: str = "N"        # N / Y
    prompt: str = ""
    initial_value: str = ""
    validation_expression: str = ""
    validation_message: str = ""
    edit_type: str = ""        # DDLB, DDDW, Checkbox, Edit, EditMask
    edit_values: str = ""
    tag: str = ""
    popup_screens: str = ""
    band: str = ""             # header, detail, footer, summary
    owning_table: str = ""     # extracted from db_name "table.column" format
    owning_service: str = ""   # derived microservice name for this table
    x: int = 0
    y: int = 0
    width: int = 0
    height: int = 0
    tabsequence: int = 0
    is_key: bool = False
    updatable: bool = False


# ─────────────────────────────────────────────────────────────────────────────
# DW TYPE MAP
# ─────────────────────────────────────────────────────────────────────────────

DW_TYPES = {
    0: "Freeform", 1: "Grid", 2: "Label", 3: "N-Up",
    4: "Group", 5: "Composite", 7: "RichText", 8: "OLE", 9: "Tree"
}


# ─────────────────────────────────────────────────────────────────────────────
# FILE READER
# ─────────────────────────────────────────────────────────────────────────────

def read_file(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    if raw[:2] == b"\xff\xfe":
        text = raw.decode("utf-16-le", errors="replace")
    elif raw[:2] == b"\xfe\xff":
        text = raw.decode("utf-16-be", errors="replace")
    elif raw[:3] == b"\xef\xbb\xbf":
        text = raw[3:].decode("utf-8", errors="replace")
    else:
        try:
            text = raw.decode("utf-8", errors="strict")
            if "\x00" in text:
                text = raw.decode("utf-16", errors="replace")
        except UnicodeDecodeError:
            text = raw.decode("cp1252", errors="replace")
    text = text.replace("\ufeff", "").replace("\x00", "")
    return text.replace("\r\n", "\n").replace("\r", "\n")


# ─────────────────────────────────────────────────────────────────────────────
# PAREN-BLOCK EXTRACTORS
# ─────────────────────────────────────────────────────────────────────────────

def _derive_service_name(table: str) -> str:
    """Derive microservice name from table name. ap_vendor → VendorService"""
    import re as _re
    name = _re.sub(r"^(ap_|mc_|gl_|ar_|po_|hr_|pr_|im_)", "", table,
                   flags=_re.IGNORECASE)
    return "".join(w.capitalize() for w in name.split("_")) + "Service"


def extract_paren_blocks(text: str, keyword: str) -> List[str]:
    """Extract keyword(...) blocks, handling nested parens."""
    results = []
    for m in re.finditer(r'\b' + re.escape(keyword) + r'\s*\(', text, re.IGNORECASE):
        start, depth, i = m.end(), 1, m.end()
        while i < len(text) and depth > 0:
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            i += 1
        if depth == 0:
            results.append(text[start:i - 1])
    return results


def extract_coldef_blocks(text: str) -> List[str]:
    """Extract column=(...) blocks (data defs inside table block)."""
    results = []
    for m in re.finditer(r'\bcolumn\s*=\s*\(', text, re.IGNORECASE):
        start, depth, i = m.end(), 1, m.end()
        while i < len(text) and depth > 0:
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            i += 1
        if depth == 0:
            results.append(text[start:i - 1])
    return results


def extract_visual_col_blocks(text: str) -> List[str]:
    """Extract visual column(...) blocks (have x= coordinate)."""
    results = []
    for m in re.finditer(r'(?<!=)\bcolumn\s*\(', text, re.IGNORECASE):
        start, depth, i = m.end(), 1, m.end()
        while i < len(text) and depth > 0:
            if text[i] == '(':
                depth += 1
            elif text[i] == ')':
                depth -= 1
            i += 1
        if depth == 0:
            block = text[start:i - 1]
            if re.search(r'\bx\s*=', block):
                results.append(block)
    return results


# ─────────────────────────────────────────────────────────────────────────────
# ATTRIBUTE EXTRACTORS
# ─────────────────────────────────────────────────────────────────────────────

def extract_attr(text: str, attr: str) -> str:
    """Extract attribute value; handles quoted and unquoted values with nested parens."""
    pattern = rf'{re.escape(attr)}\s*=\s*(["\'])'
    match = re.search(pattern, text, re.IGNORECASE)
    if match:
        quote_char = match.group(1)
        start_pos = match.end()
        result_chars = []
        i = start_pos
        paren_depth = 0
        while i < len(text):
            char = text[i]
            if char == quote_char:
                if i > 0 and text[i - 1] == '\\':
                    result_chars.append(char)
                    i += 1
                    continue
                if paren_depth == 0:
                    break
                else:
                    result_chars.append(char)
                    i += 1
                    continue
            if char == '(':
                paren_depth += 1
            elif char == ')':
                paren_depth -= 1
            result_chars.append(char)
            i += 1
        return ''.join(result_chars)
    # Try unquoted
    m2 = re.search(rf'\b{re.escape(attr)}\s*=\s*(\S+)', text, re.IGNORECASE)
    if m2:
        v = m2.group(1).rstrip(')').strip()
        v = v.replace('~"', '').replace('~', '')
        return v
    return ""


def extract_prop(attr_text: str, name: str, default=None) -> Optional[str]:
    """Legacy simple prop extractor used for table() blocks."""
    m = re.search(rf'\b{re.escape(name)}\s*=\s*("([^"]*)"|\S+)', attr_text, re.IGNORECASE)
    if not m:
        return default
    v = m.group(1)
    if v.startswith('"') and v.endswith('"'):
        v = v[1:-1]
    v = v.replace('~"', '').replace('~', '')
    return v if v else default


def extract_int_attr(text: str, attr: str) -> int:
    val = extract_attr(text, attr)
    try:
        return int(val)
    except (ValueError, TypeError):
        return 0


def extract_protect_value(protect_str: str) -> str:
    """Interpret PB protect= value: 0→N, 1→Y, 0~tIf(...)→expression."""
    if not protect_str:
        return "N"
    protect_str = protect_str.strip('"\'')
    if protect_str == "0":
        return "N"
    if protect_str == "1":
        return "Y"
    if '~t' in protect_str:
        parts = protect_str.split('~t', 1)
        if len(parts) == 2:
            default_val = parts[0].strip()
            expression = parts[1].strip()
            if default_val == "1":
                return f"Y ({expression})"
            elif expression:
                return expression
            return "N"
    if 'if(' in protect_str.lower() or 'case(' in protect_str.lower():
        return protect_str
    return "N" if protect_str == "0" else ("Y" if protect_str == "1" else protect_str)


def extract_required_value(required_str: str) -> str:
    """Interpret PB required= value: yes/1→Y, no/0→N."""
    if not required_str:
        return "N"
    rs = required_str.strip('"\'').lower()
    if rs in ("yes", "y", "true", "1"):
        return "Y"
    if rs in ("no", "n", "false", "0"):
        return "N"
    return "N"


# ─────────────────────────────────────────────────────────────────────────────
# SQL UTILITIES
# ─────────────────────────────────────────────────────────────────────────────

_SKIP_TABLES = {
    "select", "where", "and", "or", "not", "null", "as", "set", "into", "values", "case",
    "when", "then", "else", "end", "on", "in", "like", "between", "is", "by", "order",
    "group", "having", "union", "all", "exists", "distinct", "the", "a", "an",
    "lcur", "dbo", "with", "cursor", "sqlca", "from"
}


def valid_table_name(t: str) -> bool:
    return (t.lower() not in _SKIP_TABLES
            and not re.match(r'^\d+$', t)
            and len(t) > 1)


def clean_sql(sql: str) -> str:
    return (sql.replace('~"', '"')
               .replace("~r~n", "\n")
               .replace("~n", "\n")
               .replace("~t", "\t")
               .strip())


def extract_tables_from_pbselect(sql: str) -> List[str]:
    tables = set()
    for m in re.finditer(r'TABLE\s*\(\s*NAME\s*=\s*~?"?(\w+)', sql, re.IGNORECASE):
        t = m.group(1).lower()
        if valid_table_name(t):
            tables.add(t)
    return sorted(tables)


def extract_tables_from_sql(sql: str) -> List[str]:
    tables = set()
    for m in re.finditer(r"\b(?:FROM|JOIN)\s+(\w+)", sql, re.IGNORECASE):
        if valid_table_name(m.group(1)):
            tables.add(m.group(1).lower())
    for m in re.finditer(r"\bUPDATE\s+(\w+)\s+SET\b", sql, re.IGNORECASE):
        if valid_table_name(m.group(1)):
            tables.add(m.group(1).lower())
    for m in re.finditer(r"\bINSERT\s+INTO\s+(\w+)\b", sql, re.IGNORECASE):
        if valid_table_name(m.group(1)):
            tables.add(m.group(1).lower())
    for m in re.finditer(r'dbname="(\w+)\.\w+"', sql):
        if valid_table_name(m.group(1)):
            tables.add(m.group(1).lower())
    return sorted(tables)


# ─────────────────────────────────────────────────────────────────────────────
# LOOKUP COUNT
# ─────────────────────────────────────────────────────────────────────────────

def count_lookups(content: str) -> int:
    dddw_count = len(re.findall(r'dddw\.', content, re.IGNORECASE))
    lookup_count = len(set(re.findall(r'(sjmp_|look_)\w+', content, re.IGNORECASE)))
    return max(dddw_count, lookup_count)


# ─────────────────────────────────────────────────────────────────────────────
# MAIN SRD PARSER
# ─────────────────────────────────────────────────────────────────────────────

def parse_datawindow(file_path: str, content: str) -> Dict[str, Any]:
    stem = Path(file_path).stem
    result: Dict[str, Any] = {
        "file":              file_path,
        "name":              stem,
        "type":              "unknown",
        "presentation_style": "Freeform",
        "controls":          [],
        "table_columns":     [],
        "sql_query":         None,
        "tables":            [],
        "arguments":         [],
        "computed_fields":   [],
        "filters":           [],
        "sorts":             [],
        # New arrays (Fixes 1-3)
        "sections":          [],   # vtab visual tab groupings with column lists
        "lookup_controls":   [],   # sjmp_/look_/lbin_/xref_ controls
        "navigation_buttons":[],   # wind_/rprt_ window/report launchers
        # Counts (for Excel summary)
        "total_fields":      0,
        "column_count":      0,
        "text_count":        0,
        "button_count":      0,
        "dropdown_count":    0,
        "checkbox_count":    0,
        "image_count":       0,
        "rectangle_count":   0,
        "line_count_":       0,   # underscore to avoid clash with list
        "compute_count":     0,
        "radiobutton_count": 0,
        "lookup_count":      0,
        "grid_count":        0,
    }

    # ── 1. DW type / presentation style ──────────────────────────────────────
    content_lower = content.lower()
    if 'processing=1' in content_lower or 'style(type=grid)' in content_lower:
        result["presentation_style"] = "Grid"
        result["grid_count"] = 1
    elif 'style(type=tabular)' in content_lower:
        result["presentation_style"] = "Tabular"
    elif 'style(type=freeform)' in content_lower:
        result["presentation_style"] = "Freeform"
    elif 'style(type=group)' in content_lower:
        result["presentation_style"] = "Group"
    elif 'style(type=composite)' in content_lower:
        result["presentation_style"] = "Composite"
    elif 'style(type=crosstab)' in content_lower:
        result["presentation_style"] = "Crosstab"
    elif 'style(type=richtext)' in content_lower:
        result["presentation_style"] = "RichText"
    elif 'style(type=ole)' in content_lower:
        result["presentation_style"] = "OLE"

    for block in extract_paren_blocks(content, "datawindow"):
        m = re.search(r"processing\s*=\s*(\d+)", block, re.IGNORECASE)
        if m:
            dw_int = int(m.group(1))
            result["type"] = DW_TYPES.get(dw_int, "unknown")
            result["presentation_style"] = DW_TYPES.get(dw_int, result["presentation_style"])
            if dw_int == 1:
                result["grid_count"] = 1
            break

    # ── 2. SQL + table columns from table() block ─────────────────────────────
    for table_block in extract_paren_blocks(content, "table"):
        # SQL retrieve
        m = re.search(r'retrieve\s*=\s*"([^"]+)"', table_block, re.IGNORECASE)
        if m and not result["sql_query"]:
            raw_sql = clean_sql(m.group(1))
            result["sql_query"] = raw_sql
            result["tables"] = (
                extract_tables_from_pbselect(raw_sql)
                if raw_sql.upper().strip().startswith("PBSELECT")
                else extract_tables_from_sql(raw_sql)
            )

        # Data column defs — column=(...) inside table block
        for col_def in extract_coldef_blocks(table_block):
            name = extract_prop(col_def, "name")
            if not name:
                continue
            ci = ColumnInfo(name=name)
            ci.field_type = "Column"
            ci.data_type = extract_prop(col_def, "type") or ""
            ci.db_name = extract_prop(col_def, "dbname") or ""
            # Parse "table.column" from db_name to get owning table and service
            if ci.db_name and "." in ci.db_name:
                ci.owning_table   = ci.db_name.split(".")[0].lower()
                ci.owning_service = _derive_service_name(ci.owning_table)
            elif ci.db_name and "." not in ci.db_name and ci.db_name.strip():
                # Gap 10: no table qualifier — computed or session variable
                ci.owning_table   = "_computed_"
                ci.owning_service = "_computed_"
            ci.initial_value = extract_prop(col_def, "initial") or ""
            ci.validation_expression = extract_prop(col_def, "validation") or ""
            ci.validation_message = extract_prop(col_def, "validationmsg") or ""

            tag_val = extract_attr(col_def, "tag")
            if tag_val:
                ci.tag = tag_val

            required_val = extract_prop(col_def, "required")
            ci.required = extract_required_value(required_val or "")

            protect_val = extract_prop(col_def, "protect")
            ci.protected = extract_protect_value(protect_val or "")

            values = extract_prop(col_def, "values")
            if values:
                ci.edit_values = values.replace('\t', '|').replace('/', '|')
                ci.edit_type = "DDLB"

            if re.search(r"\bkey\s*=\s*yes", col_def, re.IGNORECASE):
                ci.is_key = True
            if re.search(r"\bupdate\s*=\s*yes", col_def, re.IGNORECASE):
                ci.updatable = True

            result["table_columns"].append(asdict(ci))

    # ── 2b. Fallback table extraction ─────────────────────────────────────────
    if not result["tables"]:
        t = set()
        for m in re.finditer(r'dbname="(\w+)\.\w+"', content):
            if valid_table_name(m.group(1)):
                t.add(m.group(1).lower())
        result["tables"] = sorted(t)

    # ── 3. Visual column blocks — merge into table_columns ────────────────────
    # Build lookup dict by name for quick merge
    col_by_name: Dict[str, Dict] = {c["name"]: c for c in result["table_columns"]}

    for block in extract_visual_col_blocks(content):
        # Use strict pattern: bare name= only, NOT dddw.datawindow.name= etc.
        _nm = re.search(r'(?<![.\w])name\s*=\s*(\w+)', block, re.IGNORECASE)
        name = _nm.group(1) if _nm else ""
        if not name:
            continue
        band = extract_attr(block, "band") or ""
        visible_raw = extract_attr(block, "visible") or "1"
        visible = "Y" if visible_raw.strip() in ("1", "yes", "true") else "N"
        x = extract_int_attr(block, "x")
        y = extract_int_attr(block, "y")
        w = extract_int_attr(block, "width")
        h = extract_int_attr(block, "height")
        tabseq = extract_int_attr(block, "tabsequence")
        tag_val = extract_attr(block, "tag")

        # Detect edit style
        edit_type = ""
        dddw_dataobject = ""     # cross-DW reference e.g. d_im_site_purchasing_dddw
        block_lower = block.lower()
        if 'edit.style=dddw' in block_lower or ('dddw' in block_lower and 'edit' in block_lower):
            edit_type = "DDDW"
            # Capture the DDDW dataobject name — PB syntax:
            #   dddw.name = d_im_site_purchasing_dddw   (unquoted identifier)
            #   dddw.datawindow.name = d_im_site_purchasing_dddw
            for dddw_pat in (
                r"dddw\.datawindow\.name\s*=\s*\"?([\w]+)",
                r"dddw\.name\s*=\s*\"?([\w]+)",
            ):
                dm = re.search(dddw_pat, block, re.IGNORECASE)
                if dm:
                    dddw_dataobject = dm.group(1)
                    break
            # Also catch pattern: edit.datawindow.name = "d_xxx"
            if not dddw_dataobject:
                dm2 = re.search(r"edit\.datawindow\.name\s*=\s*\"?([\w]+)", block, re.IGNORECASE)
        elif 'edit.style=ddlb' in block_lower or ('ddlb' in block_lower and 'edit' in block_lower):
            edit_type = "DDLB"
        elif 'edit.style=checkbox' in block_lower:
            edit_type = "Checkbox"
        elif 'edit.style=editmask' in block_lower:
            edit_type = "EditMask"
        elif 'edit.style=edit' in block_lower:
            edit_type = "Edit"

        # Re-check protect / required in visual block
        protect_val = extract_attr(block, "protect")
        required_val = extract_attr(block, "required")

        if name in col_by_name:
            existing = col_by_name[name]
            existing["band"] = band
            existing["visible"] = visible
            existing["x"] = x
            existing["y"] = y
            existing["width"] = w
            existing["height"] = h
            existing["tabsequence"] = tabseq
            if edit_type:
                existing["edit_type"] = edit_type
            if dddw_dataobject and not existing.get("dddw_dataobject"):
                existing["dddw_dataobject"] = dddw_dataobject
            # Ensure owning_table/service are populated if db_name was set
            if not existing.get("owning_table") and existing.get("db_name") and "." in existing["db_name"]:
                existing["owning_table"]   = existing["db_name"].split(".")[0].lower()
                existing["owning_service"] = _derive_service_name(existing["owning_table"])
            if tag_val and not existing.get("tag"):
                existing["tag"] = tag_val
            if protect_val:
                existing["protected"] = extract_protect_value(protect_val)
            if required_val:
                existing["required"] = extract_required_value(required_val)
        else:
            # Visual-only column (not in table block)
            ci = ColumnInfo(name=name)
            ci.field_type = "Column"
            ci.band = band
            ci.visible = visible
            ci.x = x
            ci.y = y
            ci.width = w
            ci.height = h
            ci.tabsequence = tabseq
            ci.edit_type = edit_type
            if dddw_dataobject:
                ci_dict = asdict(ci)
                ci_dict["dddw_dataobject"] = dddw_dataobject
                result["table_columns"].append(ci_dict)
                col_by_name[name] = result["table_columns"][-1]
                continue   # already appended
            if tag_val:
                ci.tag = tag_val
            if protect_val:
                ci.protected = extract_protect_value(protect_val)
            if required_val:
                ci.required = extract_required_value(required_val)
            result["table_columns"].append(asdict(ci))
            col_by_name[name] = result["table_columns"][-1]

    # ── 4. Retrieval arguments ────────────────────────────────────────────────
    for m in re.finditer(r'arguments=\(\("(\w+)",\s*(\w+)\)', content):
        result["arguments"].append({"name": m.group(1), "type": m.group(2)})

    # Also try v8-style arg pattern
    arg_match = re.search(r'arguments\s*=\s*\(\s*\((.*?)\)', content, re.IGNORECASE)
    if arg_match and not result["arguments"]:
        for arg in re.findall(r'"([^"]+)"', arg_match.group(1)):
            result["arguments"].append({"name": arg, "type": ""})

    # ── 5. Computed fields ────────────────────────────────────────────────────
    # Use paren-balanced extractor so expressions like
    # "credit_limit_amount - current_balance" with nested parens are
    # captured in full. Falls back to regex if balanced extractor finds nothing.
    found_computes: set = set()

    # Pass 1 — paren-balanced: extract every compute(...) block then parse
    for comp_block in extract_paren_blocks(content, "compute"):
        nm_m   = re.search(r'\bname\s*=\s*(\w+)', comp_block, re.IGNORECASE)
        band_m = re.search(r'\bband\s*=\s*(\w+)', comp_block, re.IGNORECASE)
        expr_m = re.search(r'\bexpression\s*=\s*"([^"]*)"', comp_block, re.IGNORECASE)
        if not nm_m:
            continue
        nm   = nm_m.group(1)
        band = band_m.group(1) if band_m else "detail"
        expr = expr_m.group(1) if expr_m else ""
        if nm in found_computes:
            continue
        found_computes.add(nm)
        result["computed_fields"].append({
            "name":       nm,
            "band":       band,
            "expression": expr[:300],
        })

    # Pass 2 — regex fallback for any compute blocks not found by Pass 1
    # (catches alternate PB syntax where expression comes before name)
    for m in re.finditer(
        r'compute\s*\(\s*band\s*=\s*(\w+)[^)]*?expression\s*=\s*"([^"]*)"[^)]*?name\s*=\s*(\w+)[^)]*\)',
        content, re.IGNORECASE
    ):
        nm = m.group(3)
        if nm not in found_computes:
            found_computes.add(nm)
            result["computed_fields"].append({
                "name":       nm,
                "band":       m.group(1),
                "expression": m.group(2)[:300],
            })

    # ── 6. Filters and Sorts ──────────────────────────────────────────────────
    for m in re.finditer(r'filter\s*=\s*["\']([^"\']+)["\']', content, re.IGNORECASE):
        result["filters"].append(m.group(1))
    for m in re.finditer(r'sort\s*=\s*["\']([^"\']+)["\']', content, re.IGNORECASE):
        result["sorts"].append(m.group(1))

    # ── 7. UI Controls ────────────────────────────────────────────────────────
    controls: List[Dict] = []

    # ── 7a. Text labels ───────────────────────────────────────────────────────
    found_texts: set = set()
    text_pats = [
        r'text\s*\(\s*band\s*=\s*(\w+)[^)]*?text\s*=\s*"([^"]*)"[^)]*?name\s*=\s*(\w+)[^)]*\)',
        r'text\s*\([^)]*?name\s*=\s*(\w+)[^)]*?text\s*=\s*"([^"]*)"[^)]*\)',
    ]
    for pat in text_pats:
        for m in re.finditer(pat, content, re.IGNORECASE):
            grps = m.groups()
            band, text_val, nm = (grps[0], grps[1], grps[2]) if len(grps) == 3 else ("detail", grps[1], grps[0])
            if nm in found_texts:
                continue
            found_texts.add(nm)
            col_text_block = m.group(0)
            ci = ColumnInfo(name=nm)
            ci.field_type = "Text"
            ci.band = band
            ci.column_name = text_val
            ci.visible = "Y"
            ci.x = extract_int_attr(col_text_block, "x")
            ci.y = extract_int_attr(col_text_block, "y")
            ci.width = extract_int_attr(col_text_block, "width")
            ci.height = extract_int_attr(col_text_block, "height")
            tag_val = extract_attr(col_text_block, "tag")
            if tag_val:
                ci.tag = tag_val
            controls.append(asdict(ci))

    # ── 7b. Compute controls ──────────────────────────────────────────────────
    found_computes_ctrl: set = set()
    compute_pats = [
        r'compute\s*\(\s*band\s*=\s*(\w+)[^)]*?expression\s*=\s*"([^"]*)"[^)]*?name\s*=\s*(\w+)[^)]*\)',
        r'compute\s*\([^)]*?name\s*=\s*(\w+)[^)]*\)',
    ]
    for pat in compute_pats:
        for m in re.finditer(pat, content, re.IGNORECASE):
            grps = m.groups()
            if len(grps) == 3:
                band, expr, nm = grps
            elif len(grps) == 1:
                nm, band, expr = grps[0], "detail", ""
            else:
                continue
            if nm in found_computes_ctrl:
                continue
            found_computes_ctrl.add(nm)
            ci = ColumnInfo(name=nm)
            ci.field_type = "Compute"
            ci.band = band
            ci.validation_expression = expr or ""
            ci.visible = "Y"
            tag_val = extract_attr(m.group(0), "tag")
            if tag_val:
                ci.tag = tag_val
            controls.append(asdict(ci))

    # ── 7c. Buttons (Gap 8: multiline SRD, label+position extracted) ──────────
    found_buttons: set = set()
    # DOTALL allows name= to be on a different line from button(
    for m in re.finditer(
        r'(?<!\w)button\s*\(([^)]*(?:\([^)]*\)[^)]*)*)\)',
        content, re.IGNORECASE | re.DOTALL
    ):
        block = m.group(1)
        nm_m  = re.search(r'\bname\s*=\s*(\w+)', block, re.IGNORECASE)
        if not nm_m:
            continue
        nm = nm_m.group(1)
        if nm in found_buttons:
            continue
        found_buttons.add(nm)
        ci = ColumnInfo(name=nm)
        ci.field_type = "Button"
        ci.visible    = "Y"
        txt_m = re.search(r'\btext\s*=\s*"([^"]*)"\s*', block, re.IGNORECASE)
        if txt_m:
            ci.column_name = txt_m.group(1).strip()
        for attr, fld in [("x","x"),("y","y"),("width","width"),("height","height")]:
            am = re.search(rf'\b{attr}\s*=\s*(\d+)', block, re.IGNORECASE)
            if am:
                setattr(ci, fld, int(am.group(1)))
        tag_val = extract_attr(block, "tag")
        if tag_val:
            ci.tag = tag_val
        controls.append(asdict(ci))

    # ── 7d. Bitmaps / Images (Fix 4: detect special control types) ─────────────
    found_bitmaps: set = set()
    for m in re.finditer(r'bitmap\s*\([^)]*?name\s*=\s*(\w+)[^)]*\)', content, re.IGNORECASE):
        nm = m.group(1)
        if nm in found_bitmaps:
            continue
        found_bitmaps.add(nm)
        ci = ColumnInfo(name=nm)
        ci.visible = "Y"
        # Fix 4: classify by name prefix — these have semantic meaning
        nm_lower = nm.lower()
        if nm_lower.startswith("sdml_"):
            ci.field_type = "EmailLink"
        elif nm_lower.startswith("hurl_"):
            ci.field_type = "Hyperlink"
        elif nm_lower.startswith("cstm_"):
            ci.field_type = "CustomControl"
        elif nm_lower.startswith("lbin_"):
            ci.field_type = "InlineButton"
        elif nm_lower.startswith("xref_"):
            ci.field_type = "CrossRef"
        else:
            ci.field_type = "Image"
        tag_val = extract_attr(m.group(0), "tag")
        if tag_val:
            ci.tag = tag_val
        controls.append(asdict(ci))

    # ── 7e. Rectangles ────────────────────────────────────────────────────────
    found_rects: set = set()
    for m in re.finditer(r'rectangle\s*\([^)]*?name\s*=\s*(\w+)[^)]*\)', content, re.IGNORECASE):
        nm = m.group(1)
        if nm in found_rects:
            continue
        found_rects.add(nm)
        ci = ColumnInfo(name=nm)
        ci.field_type = "Rectangle"
        ci.visible = "Y"
        tag_val = extract_attr(m.group(0), "tag")
        if tag_val:
            ci.tag = tag_val
        controls.append(asdict(ci))

    # ── 7f. Lines ─────────────────────────────────────────────────────────────
    found_lines: set = set()
    for m in re.finditer(r'line\s*\([^)]*?name\s*=\s*(\w+)[^)]*\)', content, re.IGNORECASE):
        nm = m.group(1)
        if nm in found_lines:
            continue
        found_lines.add(nm)
        ci = ColumnInfo(name=nm)
        ci.field_type = "Line"
        ci.visible = "Y"
        tag_val = extract_attr(m.group(0), "tag")
        if tag_val:
            ci.tag = tag_val
        controls.append(asdict(ci))

    # ── 7g. GroupBoxes ────────────────────────────────────────────────────────
    for m in re.finditer(r'groupbox\s*\([^)]*?name\s*=\s*(\w+)[^)]*\)', content, re.IGNORECASE):
        ci = ColumnInfo(name=m.group(1))
        ci.field_type = "GroupBox"
        ci.visible = "Y"
        tag_val = extract_attr(m.group(0), "tag")
        if tag_val:
            ci.tag = tag_val
        controls.append(asdict(ci))

    # ── 7h. RadioButtons ─────────────────────────────────────────────────────
    # PB SRD syntax:  radiobutton(name=rb_status band=detail x=.. y=.. ...)
    # Each radio button is a separate control in PB DataWindows
    found_radios: set = set()
    for m in re.finditer(r'radiobutton\s*\([^)]*?name\s*=\s*(\w+)[^)]*\)', content, re.IGNORECASE):
        nm = m.group(1)
        if nm in found_radios:
            continue
        found_radios.add(nm)
        ci = ColumnInfo(name=nm)
        ci.field_type = "RadioButton"
        ci.visible = "Y"
        ci.band = extract_attr(m.group(0), "band") or "detail"
        ci.x = extract_int_attr(m.group(0), "x")
        ci.y = extract_int_attr(m.group(0), "y")
        ci.width = extract_int_attr(m.group(0), "width")
        ci.height = extract_int_attr(m.group(0), "height")
        # Radio buttons carry the display label in the 'text' attribute
        label = extract_attr(m.group(0), "text")
        if label:
            ci.column_name = label
        tag_val = extract_attr(m.group(0), "tag")
        if tag_val:
            ci.tag = tag_val
        controls.append(asdict(ci))

    # ── 7i. Popup screen detection (sjmp_ / look_ patterns) ──────────────────
    popup_matches = re.findall(r'(sjmp_|look_)(\w+)', content, re.IGNORECASE)
    for col_dict in result["table_columns"]:
        for prefix, field_name in popup_matches:
            if field_name in col_dict["name"] or col_dict["name"] in field_name:
                popup_entry = f"{prefix}{field_name}"
                existing_popups = col_dict.get("popup_screens", "")
                if popup_entry not in existing_popups:
                    col_dict["popup_screens"] = (
                        f"{existing_popups}, {popup_entry}" if existing_popups else popup_entry
                    )

    # Pair text labels to column controls (Fix 5: name-suffix priority over x-position)
    # Priority 1: exact _t suffix match  e.g. vendor_id_t  → vendor_id
    # Priority 2: x-position match — only if label not already claimed by another column
    # Priority 3: snake_case → Title Case fallback
    label_map: Dict[str, str] = {}
    # Pass 1: name-suffix match (most reliable — never collides)
    for c in controls:
        if c.get("field_type") == "Text" and c.get("name", "").endswith("_t") and c.get("column_name"):
            base = c["name"][:-2]   # strip trailing _t
            if base not in label_map:   # first match wins, prevents duplicates
                label_map[base] = c["column_name"]
    # Pass 2: x-position match — only for columns still without a label
    text_by_x: Dict[int, str] = {}
    for c in controls:
        if c.get("field_type") == "Text" and c.get("x") and c.get("column_name"):
            x = c["x"]
            if x not in text_by_x:   # first text control at this x wins
                text_by_x[x] = c["column_name"]
    for col_dict in result["table_columns"]:
        if col_dict.get("field_type") == "Column":
            nm = col_dict.get("name", "")
            if nm and nm not in label_map and col_dict.get("x") and col_dict["x"] in text_by_x:
                candidate = text_by_x[col_dict["x"]]
                # Only use x-match if this candidate label is not already owned by
                # another column via name-suffix (prevents allow_ach_account_debit collision)
                already_claimed = any(v == candidate for k, v in label_map.items() if k != nm)
                if not already_claimed:
                    label_map[nm] = candidate
    # Apply labels with fallback
    for col_dict in result["table_columns"]:
        if col_dict.get("field_type") == "Column":
            nm = col_dict.get("name", "")
            if nm and not col_dict.get("column_name"):
                if nm in label_map:
                    col_dict["column_name"] = label_map[nm]
                else:
                    col_dict["column_name"] = nm.replace("_", " ").title()

    # Strip None values from controls
    result["controls"] = [
        {k: v for k, v in c.items() if v is not None and v != "" and v != 0}
        for c in controls
        if c.get("name")
    ]

    # ── 8a. Fix 2: lookup_controls[] — sjmp_/look_/lbin_/xref_ ─────────────────
    seen_lookup: set = set()
    lookup_controls: List[Dict] = []
    kind_map = {
        "sjmp_": "LookupJump",
        "look_": "LookupSearch",
        "lbin_": "LookupInline",
        "xref_": "CrossReference",
    }
    for m in re.finditer(r'\b(sjmp_|look_|lbin_|xref_)(\w+)', content, re.IGNORECASE):
        prefix     = m.group(1).lower()
        field_part = m.group(2).lower()
        ctrl_name  = prefix + field_part
        if ctrl_name in seen_lookup:
            continue
        seen_lookup.add(ctrl_name)
        lookup_controls.append({
            "name":          ctrl_name,
            "kind":          kind_map.get(prefix, "Lookup"),
            "linked_column": field_part,
        })
    result["lookup_controls"] = lookup_controls

    # ── 8b. Fix 3: navigation_buttons[] — wind_/rprt_ window/report launchers ──
    seen_nav: set = set()
    nav_buttons: List[Dict] = []
    for m in re.finditer(r'\b(wind_|rprt_)(\w+)', content, re.IGNORECASE):
        prefix      = m.group(1).lower()
        target_part = m.group(2).lower()
        btn_name    = prefix + target_part
        if btn_name in seen_nav:
            continue
        seen_nav.add(btn_name)
        nav_buttons.append({
            "name":          btn_name,
            "kind":          "WindowLaunch" if prefix == "wind_" else "ReportLaunch",
            "target_window": target_part,
            "label":         target_part.replace("_", " ").title(),
        })
    result["navigation_buttons"] = nav_buttons

    # ── 8c. Fix 1: sections[] — vtab visual tab groupings ───────────────────────
    # Standard tab name map: vtab suffix → human label
    _TAB_NAME_MAP = {
        "default": "Main", "credit": "Credit", "options": "Options",
        "tax": "Tax", "bank": "Banking", "ach": "ACH",
        "address": "Address", "addr": "Address", "payment": "Payment",
    }
    # Fields that belong to the Credit tab
    _CREDIT_FIELDS = {
        "current_balance", "credit_limit_amount", "available_credit",
        "credit_limit_in_hc", "current_balance_in_hc", "available_credit_in_hc",
        "min_order_amount", "max_purchase_amount", "min_payment_amount",
        "min_payment_percent", "max_writeoff_amount", "backup_withholding_rate",
        "backup_withholding_reason", "invalid_tin_count",
        "tax_identification_number", "tax_registration_number", "tax_1099_type",
    }
    # Fields that belong to the Options tab
    _OPTION_FIELDS = {
        "track_period_summary", "self_assessment_tax_default", "self_assessment_tax_prompt",
        "separate_check", "trans_payment_address_required", "electronic_payment_type",
        "electronic_notification_type", "ach_prenotification_status",
        "ach_prenotification_date", "ach_create_prenotification", "ach_entry_class_code",
        "bank_routing_number", "bank_account_number", "bank_account_type",
        "allow_ach_account_debit", "payment_id", "vendor_cert_status",
    }
    tabs: List[Dict] = []
    seen_vtab: set = set()
    for m in re.finditer(r'\bvtab_(\w+)\b', content, re.IGNORECASE):
        vname = "vtab_" + m.group(1).lower()
        if vname in seen_vtab:
            continue
        seen_vtab.add(vname)
        part  = m.group(1).lower()
        label = _TAB_NAME_MAP.get(part, part.replace("_", " ").title())
        tabs.append({"name": vname, "label": label, "columns": []})
    if tabs:
        tab_map = {t["label"]: t for t in tabs}
        for col_dict in result["table_columns"]:
            cname = col_dict.get("name", "")
            if cname in _CREDIT_FIELDS and "Credit" in tab_map:
                tab_map["Credit"]["columns"].append(cname)
            elif cname in _OPTION_FIELDS and "Options" in tab_map:
                tab_map["Options"]["columns"].append(cname)
            elif "Main" in tab_map:
                tab_map["Main"]["columns"].append(cname)
            elif tabs:
                tabs[0]["columns"].append(cname)
    result["sections"] = tabs

    # ── 8d. Fix 6: DDDW rescan — set dddw_dataobject on ALL dddw columns ────────
    for block in extract_visual_col_blocks(content):
        if "dddw" not in block.lower():
            continue
        nm_m = re.search(r'(?<![.\w])name\s*=\s*(\w+)', block, re.IGNORECASE)
        if not nm_m:
            continue
        col_name = nm_m.group(1)
        if col_name not in col_by_name:
            continue
        entry = col_by_name[col_name]
        entry["edit_type"] = "DDDW"
        if not entry.get("dddw_dataobject"):
            for pat in [
                r'dddw\.datawindow\.name\s*=\s*["\']?([\w]+)',
                r'dddw\.name\s*=\s*["\']?([\w]+)',
                r'edit\.datawindow\.name\s*=\s*["\']?([\w]+)',
            ]:
                dm = re.search(pat, block, re.IGNORECASE)
                if dm:
                    entry["dddw_dataobject"] = dm.group(1)
                    break

    # ── 8. Lookup count ───────────────────────────────────────────────────────
    result["lookup_count"] = count_lookups(content)

    # ── 9. Counts ─────────────────────────────────────────────────────────────
    all_cols = result["table_columns"] + result["controls"]
    for c in all_cols:
        ft = c.get("field_type", "")
        et = c.get("edit_type", "")
        if ft == "Column":
            result["column_count"] += 1
        elif ft == "Text":
            result["text_count"] += 1
        elif ft == "Button":
            result["button_count"] += 1
        elif ft == "Image":
            result["image_count"] += 1
        elif ft == "Rectangle":
            result["rectangle_count"] += 1
        elif ft == "Line":
            result["line_count_"] += 1
        elif ft == "Compute":
            result["compute_count"] += 1
        if ft == "RadioButton":
            result["radiobutton_count"] += 1
        if et in ("DDLB", "DDDW"):
            result["dropdown_count"] += 1
        elif et == "Checkbox":
            result["checkbox_count"] += 1

    result["total_fields"] = len(all_cols)

    return result


# ─────────────────────────────────────────────────────────────────────────────
# FILE DISCOVERY
# ─────────────────────────────────────────────────────────────────────────────

def find_srd_files(project_dir: str) -> List[str]:
    files = []
    for root, dirs, names in os.walk(project_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "__MACOSX"]
        for n in names:
            if Path(n).suffix.lower() == ".srd":
                files.append(os.path.join(root, n))
    seen, unique = set(), []
    for f in files:
        b = os.path.basename(f)
        if b not in seen:
            seen.add(b)
            unique.append(f)
    return sorted(unique)


# ─────────────────────────────────────────────────────────────────────────────
# EXCEL REPORT GENERATOR
# ─────────────────────────────────────────────────────────────────────────────

class ExcelReportGenerator:
    HEADER_FONT  = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    HEADER_FILL  = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    TITLE_FONT   = Font(name="Calibri", size=14, bold=True)
    BOLD_FONT    = Font(name="Calibri", size=11, bold=True)
    NORMAL_FONT  = Font(name="Calibri", size=10)
    THIN_BORDER  = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"),  bottom=Side(style="thin")
    )

    def _header_row(self, ws, row: int, headers: List[str]):
        for ci, h in enumerate(headers, 1):
            cell = ws.cell(row=row, column=ci, value=h)
            cell.font = self.HEADER_FONT
            cell.fill = self.HEADER_FILL
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = self.THIN_BORDER

    def _data_rows(self, ws, start: int, end: int, ncols: int):
        for r in range(start, end + 1):
            for c in range(1, ncols + 1):
                cell = ws.cell(row=r, column=c)
                cell.font = self.NORMAL_FONT
                cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
                cell.border = self.THIN_BORDER

    def _col_widths(self, ws, widths: List[int]):
        for idx, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(idx)].width = w

    def _write_detail_sheet(self, ws, dw: Dict):
        """Write a per-DataWindow detail sheet."""
        ws["A1"] = f"DataWindow: {dw['name']}"
        ws["A1"].font = self.TITLE_FONT
        ws.merge_cells("A1:R1")

        row = 3
        meta = [
            ("File:", dw.get("file", "")),
            ("Presentation Style:", dw.get("presentation_style", dw.get("type", ""))),
            ("Tables:", ", ".join(dw.get("tables", []))),
            ("SQL Query:", (dw.get("sql_query") or "")[:300]),
        ]
        for label, val in meta:
            ws.cell(row=row, column=1, value=label).font = self.BOLD_FONT
            ws.cell(row=row, column=2, value=val)
            ws.merge_cells(f"B{row}:R{row}")
            row += 1

        row += 1
        ws.cell(row=row, column=1, value="Summary:").font = self.BOLD_FONT
        row += 1
        summary = [
            ("Total Fields",  dw.get("total_fields", 0)),
            ("Columns",       dw.get("column_count", 0)),
            ("Text Controls", dw.get("text_count", 0)),
            ("Buttons",       dw.get("button_count", 0)),
            ("Dropdowns",     dw.get("dropdown_count", 0)),
            ("Checkboxes",    dw.get("checkbox_count", 0)),
            ("Images",        dw.get("image_count", 0)),
            ("Rectangles",    dw.get("rectangle_count", 0)),
            ("Lines",         dw.get("line_count_", 0)),
            ("Computes",      dw.get("compute_count", 0)),
            ("Lookups",       dw.get("lookup_count", 0)),
            ("Grids",         dw.get("grid_count", 0)),
        ]
        for label, val in summary:
            ws.cell(row=row, column=1, value=label)
            ws.cell(row=row, column=2, value=val)
            row += 1

        row += 1
        headers = [
            "#", "Field Label", "Field Type", "Column Name", "Data Type",
            "Visible", "Protected", "Required", "Initial Value",
            "Validation Expression", "Validation Message", "DB Name",
            "Edit Type", "Edit Values", "Tag", "Popup Screens",
            "Band", "Tab Seq"
        ]
        self._header_row(ws, row, headers)
        header_row = row
        row += 1
        data_start = row

        all_cols = dw.get("table_columns", []) + dw.get("controls", [])
        for idx, col in enumerate(all_cols, 1):
            ws.cell(row=row, column=1,  value=idx)
            ws.cell(row=row, column=2,  value=col.get("column_name", ""))
            ws.cell(row=row, column=3,  value=col.get("field_type", ""))
            ws.cell(row=row, column=4,  value=col.get("name", ""))
            ws.cell(row=row, column=5,  value=col.get("data_type", ""))
            ws.cell(row=row, column=6,  value=col.get("visible", "Y"))
            ws.cell(row=row, column=7,  value=col.get("protected", "N"))
            ws.cell(row=row, column=8,  value=col.get("required", "N"))
            ws.cell(row=row, column=9,  value=col.get("initial_value", ""))
            ws.cell(row=row, column=10, value=col.get("validation_expression", ""))
            ws.cell(row=row, column=11, value=col.get("validation_message", ""))
            ws.cell(row=row, column=12, value=col.get("db_name", ""))
            ws.cell(row=row, column=13, value=col.get("edit_type", ""))
            ws.cell(row=row, column=14, value=col.get("edit_values", ""))
            ws.cell(row=row, column=15, value=col.get("tag", ""))
            ws.cell(row=row, column=16, value=col.get("popup_screens", ""))
            ws.cell(row=row, column=17, value=col.get("band", ""))
            ws.cell(row=row, column=18, value=col.get("tabsequence", 0) or "")
            row += 1

        if row > data_start:
            self._data_rows(ws, data_start, row - 1, len(headers))

        self._col_widths(ws, [5, 25, 12, 25, 12, 8, 18, 10, 15, 35, 30, 28, 12, 28, 20, 20, 10, 8])
        ws.freeze_panes = f"A{header_row + 1}"

    def generate(self, results: List[Dict], output_path: str):
        wb = Workbook()

        # ── Master Summary sheet ─────────────────────────────────────────────
        ws_sum = wb.active
        ws_sum.title = "Master Summary"
        ws_sum["A1"] = "PowerBuilder DataWindow Analysis — Master Summary"
        ws_sum["A1"].font = self.TITLE_FONT
        ws_sum.merge_cells("A1:L1")
        ws_sum["A2"] = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        row = 4
        sum_headers = [
            "File Name", "DW Name", "Style", "Tables",
            "Total Fields", "Columns", "Text", "Buttons",
            "Dropdowns", "Checkboxes", "Lookups", "Grids"
        ]
        self._header_row(ws_sum, row, sum_headers)
        row += 1
        data_start = row

        for dw in results:
            ws_sum.cell(row=row, column=1,  value=Path(dw.get("file", "")).name)
            ws_sum.cell(row=row, column=2,  value=dw.get("name", ""))
            ws_sum.cell(row=row, column=3,  value=dw.get("presentation_style", dw.get("type", "")))
            ws_sum.cell(row=row, column=4,  value=", ".join(dw.get("tables", [])))
            ws_sum.cell(row=row, column=5,  value=dw.get("total_fields", 0))
            ws_sum.cell(row=row, column=6,  value=dw.get("column_count", 0))
            ws_sum.cell(row=row, column=7,  value=dw.get("text_count", 0))
            ws_sum.cell(row=row, column=8,  value=dw.get("button_count", 0))
            ws_sum.cell(row=row, column=9,  value=dw.get("dropdown_count", 0))
            ws_sum.cell(row=row, column=10, value=dw.get("checkbox_count", 0))
            ws_sum.cell(row=row, column=11, value=dw.get("lookup_count", 0))
            ws_sum.cell(row=row, column=12, value=dw.get("grid_count", 0))
            row += 1

        # Totals row
        if row > data_start:
            ws_sum.cell(row=row, column=1, value="TOTAL").font = self.BOLD_FONT
            for c_idx in range(5, 13):
                col_ltr = get_column_letter(c_idx)
                ws_sum.cell(row=row, column=c_idx,
                            value=f"=SUM({col_ltr}{data_start}:{col_ltr}{row - 1})"
                            ).font = self.BOLD_FONT
            self._data_rows(ws_sum, data_start, row, len(sum_headers))

        self._col_widths(ws_sum, [30, 25, 12, 30, 12, 10, 8, 8, 10, 10, 8, 6])
        ws_sum.freeze_panes = f"A{data_start}"

        # ── Per-DW detail sheets ─────────────────────────────────────────────
        for dw in results:
            sheet_title = dw.get("name", "unknown")[:31]
            ws = wb.create_sheet(title=sheet_title)
            self._write_detail_sheet(ws, dw)

        wb.save(output_path)
        print(f"📊 Excel saved: {output_path}  ({os.path.getsize(output_path):,} bytes)")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def generate_datawindows(
    project_dir: str,
    output_json: str = "datawindows.json",
    output_xlsx: str = "datawindows_analysis.xlsx"
) -> List[Dict]:
    print(f"DataWindow extractor — scanning {project_dir}")
    files = find_srd_files(project_dir)
    print(f"  Found {len(files)} .srd files")

    results, failed = [], 0
    for fp in files:
        name = os.path.basename(fp)
        try:
            dw = parse_datawindow(fp, read_file(fp))
            results.append(dw)
            print(
                f"  ✅ {name} ({dw['presentation_style']}) → "
                f"{dw['column_count']} cols, "
                f"{dw['total_fields']} total fields, "
                f"tables={dw['tables']}"
            )
        except Exception as e:
            print(f"  ❌ {name} — FAILED: {e}")
            failed += 1

    print(f"\nParsed {len(results)} DataWindows ({failed} failed)")

    # ── Write JSON ────────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(os.path.abspath(output_json)), exist_ok=True)
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"💾 JSON saved: {output_json}  ({os.path.getsize(output_json):,} bytes)")

    # ── Write Excel ───────────────────────────────────────────────────────────
    os.makedirs(os.path.dirname(os.path.abspath(output_xlsx)), exist_ok=True)
    ExcelReportGenerator().generate(results, output_xlsx)

    return results


if __name__ == "__main__":
    generate_datawindows(
        project_dir="/Users/netraballolli/Documents/Discovery/pb_source /GL",
        output_json="datawindows.json",
        output_xlsx="datawindows_analysis.xlsx",
    )
